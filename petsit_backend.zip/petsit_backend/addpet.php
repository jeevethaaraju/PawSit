<?php
header('Content-Type: application/json');
session_start();

// 1. Verify session
if (!isset($_SESSION['petOwner']) || !isset($_SESSION['petOwner']['petOwnerId'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$petOwner_ID = $_SESSION['petOwner']['petOwnerId'];

// 2. Database connection
$conn = new mysqli("localhost", "root", "", "petsit");
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

// 3. Create uploads directory if it doesn't exist
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
}

// 4. Process input
$input = json_decode(file_get_contents('php://input'), true);

// Required fields
$required = ['petName', 'petType', 'petBreed', 'petSize', 'petGender', 'petBirthDate'];
foreach ($required as $field) {
    if (empty($input[$field])) {
        echo json_encode(['status' => 'error', 'message' => "$field is required"]);
        exit;
    }
}

// 5. Handle image upload
$petImage = null;
if (!empty($input['petImage'])) {
    // Generate unique filename
    $imageData = $input['petImage'];
    $imageName = uniqid('pet_') . '.jpg'; // You can extract extension if needed
    
    // Save the image to uploads folder
    if (preg_match('/^data:image\/(\w+);base64,/', $imageData, $type)) {
        $imageData = substr($imageData, strpos($imageData, ',') + 1);
        $imageData = base64_decode($imageData);
        
        if ($imageData !== false) {
            file_put_contents($uploadDir . $imageName, $imageData);
            $petImage = $imageName;
        }
    }
}

// 6. Save to database
try {
    if ($petImage) {
        $stmt = $conn->prepare("INSERT INTO pet 
                              (petName, petType, petBreed, petSize, petGender, petBirthDate, petOwner_ID, petImage) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssis", 
            $input['petName'],
            $input['petType'],
            $input['petBreed'],
            $input['petSize'],
            $input['petGender'],
            $input['petBirthDate'],
            $petOwner_ID,
            $petImage
        );
    } else {
        $stmt = $conn->prepare("INSERT INTO pet 
                              (petName, petType, petBreed, petSize, petGender, petBirthDate, petOwner_ID) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssi", 
            $input['petName'],
            $input['petType'],
            $input['petBreed'],
            $input['petSize'],
            $input['petGender'],
            $input['petBirthDate'],
            $petOwner_ID
        );
    }

    if ($stmt->execute()) {
        echo json_encode([
            'status' => 'success',
            'message' => 'Pet added successfully',
            'petId' => $stmt->insert_id,
            'imagePath' => $petImage ? ($uploadDir . $petImage) : null
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to add pet',
            'error' => $stmt->error
        ]);
    }
    
    $stmt->close();
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error',
        'details' => $e->getMessage()
    ]);
}

$conn->close();
?>