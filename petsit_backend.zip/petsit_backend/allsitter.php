<?php
include('config.php');
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
include 'connection.php';

// Get logged-in owner's ID from request
$ownerId = $_GET['owner_id'] ?? 0;
if ($ownerId == 0) {
    die(json_encode(['status' => 'error', 'message' => 'Owner ID is required']));
}

// Fetch owner's coordinates from database
$stmt = $conn->prepare("SELECT lat, lng FROM petowner WHERE id = ?");
$stmt->bind_param("i", $ownerId);
$stmt->execute();
$ownerResult = $stmt->get_result();

if ($ownerResult->num_rows == 0) {
    die(json_encode(['status' => 'error', 'message' => 'Owner not found']));
}

$owner = $ownerResult->fetch_assoc();
$ownerLat = (float)$owner['lat'];
$ownerLng = (float)$owner['lng'];

// Calculate distance using Vincenty formula (more accurate)
$sql = "SELECT 
    id,
    FirstName,
    ProfileImage,
    Location,  -- Include Location here
    lat,
    lng,
    ROUND(
        6371 * ATAN2(
            SQRT(
                POWER(COS(RADIANS(lat)) * SIN(RADIANS(lng - ?)), 2) +
                POWER(COS(RADIANS(?)) * SIN(RADIANS(lat)) - 
                SIN(RADIANS(?)) * COS(RADIANS(lat)) * COS(RADIANS(lng - ?)), 2)
            ),
            SIN(RADIANS(?)) * SIN(RADIANS(lat)) + 
            COS(RADIANS(?)) * COS(RADIANS(lat)) * COS(RADIANS(lng - ?))
        ),
        2
    ) AS distance
FROM petsitter
WHERE lat IS NOT NULL AND lng IS NOT NULL AND status = 'active'
HAVING distance < 100  -- Limit to 100km radius
ORDER BY distance ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ddddddd", $ownerLng, $ownerLat, $ownerLat, $ownerLng, $ownerLat, $ownerLat, $ownerLng);
$stmt->execute();
$result = $stmt->get_result();

$sitters = array();
while ($row = $result->fetch_assoc()) {
    $sitter = [
        'id' => $row['id'],
        'FirstName' => $row['FirstName'],
        'ProfileImage' => !empty($row['ProfileImage']) ? BASE_URL . ltrim($row['ProfileImage'], '/') : null,
        'Location' => $row['Location'],  // Add Location to response
        'distance' => $row['distance'],
        'distance_text' => round($row['distance'], 2) . ' km away'
    ];
    $sitters[] = $sitter;
}

// Output JSON response
echo json_encode([
    'status' => 'success',
    'owner_coordinates' => ['lat' => $ownerLat, 'lng' => $ownerLng],
    'sitters' => $sitters
]);
?>
