<?php
header("Content-Type: application/json");
require_once 'connection.php';

$response = ["exists" => false];

if (isset($_GET['userId'])) {
    $userId = (int)$_GET['userId'];
    
    $stmt = $conn->prepare("SELECT id FROM petsitter WHERE id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $response["exists"] = $result->num_rows > 0;
    
    $stmt->close();
}

echo json_encode($response);
$conn->close();
?>