<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate required parameters
if (!isset($data['owner_id']) || !isset($data['total_price'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing required parameters"
    ]);
    exit;
}

$ownerId = (int)$data['owner_id'];
$totalPrice = (float)$data['total_price'];

try {
    // Get current wallet balance
    $stmt = $conn->prepare("SELECT WalletBalance FROM petowner WHERE id = ?");
    $stmt->bind_param("i", $ownerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Owner not found");
    }

    $row = $result->fetch_assoc();
    $balance = (float)$row['WalletBalance'];
    $sufficient = $balance >= $totalPrice;

    echo json_encode([
        "status" => "success",
        "has_sufficient_funds" => $sufficient,
        "current_balance" => $balance,
        "required_amount" => $totalPrice
    ]);

} catch (Exception $e) {
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
} finally {
    $conn->close();
}
?>