<?php
// config.php
define('BASE_URL', 'http://192.168.0.7/');  // Define the base URL as a constant
?>
