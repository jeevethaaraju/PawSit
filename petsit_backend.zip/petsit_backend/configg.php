<?php
// config.php
session_set_cookie_params([
    'lifetime' => 86400,
    'path' => '/',
    'domain' => '192.168.0.7', // Your local IP
    'secure' => false,          // Disable for HTTP
    'httponly' => true,
    'samesite' => 'Lax'
]);

// Custom session handling
ini_set('session.save_handler', 'files');
ini_set('session.save_path', 'C:/xampp/tmp'); // Verify this path exists
ini_set('session.use_strict_mode', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_domain', '192.168.0.6');
?>