
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "petsit"; // or your database name

$conn = new mysqli($host, $user, $pass, $db);

// Optional: error handling
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
