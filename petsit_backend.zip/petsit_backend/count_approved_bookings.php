<?php
header("Content-Type: application/json");
include("connection.php"); // update with your DB config file

$sql = "SELECT COUNT(*) AS total FROM booking WHERE approval = 'completed'";
$result = $conn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    echo json_encode([
        "success" => true,
        "total_approved_bookings" => (int)$row['total']
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Failed to count approved bookings"
    ]);
}

$conn->close();
?>
