<?php
// Database configuration
$host = "localhost";       // Change if needed
$db_name = "petsit";  // Replace with your actual DB name
$username = "root"; // Replace with your DB username
$password = ""; // Replace with your DB password

// Create connection
$conn = new mysqli($host, $username, $password, $db_name);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connection failed: " . $conn->connect_error]));
}

// Query to count petowners
$sql = "SELECT COUNT(*) AS total FROM petsitter";
$result = $conn->query($sql);

if ($result) {
    $row = $result->fetch_assoc();
    echo json_encode([
        "success" => true,
        "total_petsitters" => $row["total"]
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "Query failed: " . $conn->error
    ]);
}

$conn->close();
?>
