<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get raw POST data
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate required parameters
if (!isset($data['owner_id']) || !isset($data['total_price'])) {
    echo json_encode([
        "status" => "error",
        "message" => "Missing required parameters"
    ]);
    exit;
}

$ownerId = (int)$data['owner_id'];
$totalPrice = (float)$data['total_price'];

// Start transaction
$conn->begin_transaction();

try {
    // 1. Get current wallet balance with row lock
    $stmt = $conn->prepare("SELECT WalletBalance FROM petowner WHERE id = ? FOR UPDATE");
    $stmt->bind_param("i", $ownerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Owner not found");
    }

    $row = $result->fetch_assoc();
    $currentBalance = (float)$row['WalletBalance'];

    // 2. Verify sufficient funds
    if ($currentBalance < $totalPrice) {
        throw new Exception("Insufficient funds");
    }

    // 3. Calculate new balance
    $newBalance = $currentBalance - $totalPrice;

    // 4. Update wallet balance
    $update = $conn->prepare("UPDATE petowner SET WalletBalance = ? WHERE id = ?");
    $update->bind_param("di", $newBalance, $ownerId);
    
    if (!$update->execute()) {
        throw new Exception("Failed to update wallet balance");
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        "status" => "success",
        "new_balance" => $newBalance,
        "message" => "Payment processed successfully"
    ]);

} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
} finally {
    $conn->close();
}
?>
