<?php
header('Content-Type: application/json');
require_once 'connection.php';

$response = array('success' => false, 'error' => '');

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    $response['error'] = "Invalid request method";
    echo json_encode($response);
    exit;
}

$petId = isset($_POST['pet_id']) ? intval($_POST['pet_id']) : 0;

if ($petId <= 0) {
    $response['error'] = "Invalid pet ID";
    echo json_encode($response);
    exit;
}

try {
    // Check if pet has any approved or pending bookings
    $stmt = $conn->prepare("SELECT COUNT(*) as booking_count FROM booking WHERE pet_id = ? AND approval IN ('approved', 'pending')");
    $stmt->bind_param("i", $petId);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    if ($row['booking_count'] > 0) {
        $response['error'] = "Cannot deactivate pet - it has approved or pending bookings";
        echo json_encode($response);
        exit;
    }

    // Update pet status to 'inactive' instead of deleting
    $stmt = $conn->prepare("UPDATE pet SET status = 'inactive' WHERE id = ?");
    $stmt->bind_param("i", $petId);
    
    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Pet status updated to inactive successfully";
    } else {
        $response['error'] = "Error updating pet status: " . $stmt->error;
    }
    
    $stmt->close();
} catch (Exception $e) {
    $response['error'] = "Database error: " . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>