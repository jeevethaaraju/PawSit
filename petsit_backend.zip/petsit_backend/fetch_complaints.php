<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "Database connection failed",
        "error" => $conn->connect_error
    ]);
    exit();
}

try {
    // Prepare and execute query with proof_image field
    $stmt = $conn->prepare("
        SELECT 
            complaint_id, 
            booking_id, 
            petOwner_ID,
            petSitter_ID,
            description,
            status,
            FromDate,
            proof_image,
            DATE_FORMAT(created_at, '%Y-%m-%d %H:%i:%s') as formatted_created_at
        FROM complaints 
        ORDER BY created_at DESC
    ");
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $complaints = [];
    
    while ($row = $result->fetch_assoc()) {
        $complaints[] = [
            "complaint_id" => (int)$row['complaint_id'],
            "booking_id" => (int)$row['booking_id'],
            "petOwner_ID" => (int)$row['petOwner_ID'],
            "petSitter_ID" => (int)$row['petSitter_ID'],
            "description" => htmlspecialchars($row['description']),
            "status" => $row['status'],
            "FromDate" => $row['FromDate'],
            "proof_image" => $row['proof_image'], // Add this field
            "created_at" => $row['formatted_created_at']
        ];
    }
    
    // Successful response
    echo json_encode([
        "success" => true,
        "count" => count($complaints),
        "data" => $complaints
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "An error occurred while fetching complaints",
        "error" => $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
?>