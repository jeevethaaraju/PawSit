<?php
header("Content-Type: application/json");
require_once 'db_connection.php';

$response = array("success" => false, "message" => "", "notifications" => array());

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (isset($_GET['user_id'])) {
        $user_id = $_GET['user_id'];
        
        try {
            $stmt = $conn->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $notifications = array();
            while ($row = $result->fetch_assoc()) {
                $notifications[] = $row;
            }
            
            $response["success"] = true;
            $response["notifications"] = $notifications;
            
            // Mark notifications as read
            $stmt = $conn->prepare("UPDATE notifications SET is_read = TRUE WHERE user_id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $stmt->close();
        } catch (Exception $e) {
            $response["message"] = "Database error: " . $e->getMessage();
        }
    } else {
        $response["message"] = "Missing user_id parameter";
    }
} else {
    $response["message"] = "Invalid request method";
}

echo json_encode($response);
$conn->close();
?>