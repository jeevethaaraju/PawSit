<?php
header('Content-Type: application/json');
require 'connection.php'; // your DB connection script

// Get and sanitize user_id from GET parameter
$user_id = isset($_GET['user_id']) ? intval($_GET['user_id']) : 0;

if ($user_id <= 0) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid user_id'
    ]);
    exit;
}

// Use the actual primary key column of your notifications table instead of 'notification_id' if different
$query = "SELECT notification_id, user_id, complaint_id, message, created_at, is_read 
          FROM notifications 
          WHERE user_id = ? 
          ORDER BY created_at DESC";

$stmt = $conn->prepare($query);

if (!$stmt) {
    echo json_encode([
        'success' => false,
        'message' => 'Database prepare failed: ' . $conn->error
    ]);
    exit;
}

$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $notifications = [];

    while ($row = $result->fetch_assoc()) {
        // Map notification_id to id for consistency with Android app
        $notifications[] = [
            'id' => $row['notification_id'],
            'user_id' => $row['user_id'],
            'complaint_id' => $row['complaint_id'],
            'message' => $row['message'],
            'created_at' => $row['created_at'],
            'is_read' => (int)$row['is_read']
        ];
    }

    echo json_encode([
        'success' => true,
        'data' => $notifications
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Database execution failed: ' . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
