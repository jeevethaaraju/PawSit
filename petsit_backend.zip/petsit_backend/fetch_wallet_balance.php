<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get owner_id from query parameters
$ownerId = isset($_GET['owner_id']) ? (int)$_GET['owner_id'] : 0;

if ($ownerId <= 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid owner ID"
    ]);
    exit;
}

try {
    // Get wallet balance
    $stmt = $conn->prepare("SELECT WalletBalance FROM petowner WHERE id = ?");
    $stmt->bind_param("i", $ownerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Owner not found");
    }

    $row = $result->fetch_assoc();
    $balance = (float)$row['WalletBalance'];

    echo json_encode([
        "status" => "success",
        "balance" => $balance,
        "currency" => "RM"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
} finally {
    $conn->close();
}
?>