<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");
require_once 'config.php';

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// Get the petsitter ID from the request
$petsitterId = isset($_GET['petsitter_id']) ? intval($_GET['petsitter_id']) : 0;

if ($petsitterId <= 0) {
    echo json_encode(["status" => "error", "message" => "Valid pet sitter ID is required"]);
    exit;
}

// Get both sitter info and their services
$query = "
    SELECT 
        ps.id AS sitter_id,
        ps.FirstName,
        ps.LastName,
        ps.ProfileImage,
        ps.lat,
        ps.lng,
        ps.Location,
        ps.Phone_Number,
        s.*
    FROM petsitter ps
    LEFT JOIN services s ON ps.id = s.petsitter_id
    WHERE ps.id = ?
    LIMIT 1
";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $petsitterId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    
    // Process service data to ensure proper format
    $acceptPet = !empty($data['accept_pet']) ? 
        (isJson($data['accept_pet']) ? json_decode($data['accept_pet']) : explode(",", $data['accept_pet'])) : 
        [];
    
    $services = !empty($data['service']) ? 
        (isJson($data['service']) ? json_decode($data['service']) : explode(",", $data['service'])) : 
        [];
    
    // Process picture URL - ensure it's a complete URL if not already
    $pictureUrl = !empty($data['picture']) ? 
        (filter_var($data['picture'], FILTER_VALIDATE_URL) ? 
            $data['picture'] : 
            BASE_URL . ltrim($data['picture'], '/')) : 
        null;
    
    // Build response
    $response = [
        "status" => "success",
        "sitter" => [
            "id" => $data['sitter_id'],
            "FirstName" => $data['FirstName'],
            "LastName" => $data['LastName'],
            "ProfileImage" => $data['ProfileImage'],
            "lat" => $data['lat'],
            "lng" => $data['lng'],
            "Location" => $data['Location'],
            "Phone_Number" => $data['Phone_Number']
        ],
        "service" => $data['id'] ? [
            "id" => $data['id'],
            "service_name" => $data['service_name'],
            "description" => $data['summ'],
            "numofpets" => $data['numofpets'],
            "accept_pet" => $acceptPet,
            "accept_petsize" => $data['accept_petsize'],
            "unsupervised" => $data['unsupervised'],
            "potty" => $data['potty'],
            "walks" => $data['walks'],
            "home" => $data['home'],
            "transport" => $data['transport'],
            "price" => $data['price'],
            "service" => $services,
            "picture" => $pictureUrl, // Use processed URL
            "petsitter_id" => $data['petsitter_id']
        ] : null
    ];
    
    echo json_encode($response);
} else {
    echo json_encode(["status" => "error", "message" => "Pet sitter not found"]);
}

// Helper function to check if string is JSON
function isJson($string) {
    json_decode($string);
    return (json_last_error() == JSON_ERROR_NONE);
}

$stmt->close();
$conn->close();
?>