<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// Database configuration
$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch all pet owners
    $stmt = $conn->prepare("SELECT id, FirstName, Email, Phone_Number FROM petsitter");
    $stmt->execute();
    
    $sitters = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($sitters) > 0) {
        echo json_encode([
            "success" => true,
            "sitters" => $sitters
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "No pet sitters found"
        ]);
    }
} catch(PDOException $e) {
    echo json_encode([
        "success" => false,
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>