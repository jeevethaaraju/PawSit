<?php
require('C:\xampp\htdocs\fpdf\fpdf.php');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Get filter parameters
    $year = $_GET['year'] ?? date('Y');
    $month = $_GET['month'] ?? null;
    $status = $_GET['status'] ?? null;
    
    // Build SQL query
    $sql = "SELECT 
        SUM(CASE WHEN approval = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN approval = 'completed' THEN 1 ELSE 0 END) as completed,
        SUM(CASE WHEN approval = 'cancelled' THEN 1 ELSE 0 END) as cancelled,
         SUM(CASE WHEN approval = 'approved' THEN 1 ELSE 0 END) as approved
        FROM booking
        WHERE YEAR(booking_date) = :year";
    
    $params = [':year' => $year];
    
    if ($month) {
        $sql .= " AND MONTH(booking_date) = :month";
        $params[':month'] = $month;
    }
    
    if ($status) {
        $sql .= " AND approval = :status";
        $params[':status'] = $status;
    }
    
    // Execute query
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Create PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    
    // Title
    $title = "Booking Report for $year";
    if ($month) {
        $monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                      'July', 'August', 'September', 'October', 'November', 'December'];
        $title .= " - " . $monthNames[$month-1];
    }
    $pdf->Cell(0,10,$title,0,1,'C');
    
    // Status filter info
    if ($status) {
        $pdf->SetFont('Arial','I',12);
        $pdf->Cell(0,10,"Status: " . ucfirst($status),0,1);
    }
    
    // Statistics
    $pdf->SetFont('Arial','',12);
    $pdf->Ln(10); // Add some space
    
    $total = $data['pending'] + $data['completed'] + $data['cancelled'] + $data['approved'];
    $pdf->Cell(0,10,"Total Bookings: $total",0,1);
    $pdf->Cell(0,10,"- Pending: " . $data['pending'],0,1);
    $pdf->Cell(0,10,"- Completed: " . $data['completed'],0,1);
    $pdf->Cell(0,10,"- Cancelled: " . $data['cancelled'],0,1);
        $pdf->Cell(0,10,"- Approved: " . $data['approved'],0,1);
    
    // Recent bookings table
    $pdf->Ln(15);
    $pdf->SetFont('Arial','B',14);
    $pdf->Cell(0,10,'Recent Bookings',0,1);
    
    $sqlRecent = "SELECT booking_id, booking_date, approval 
                 FROM booking 
                 WHERE YEAR(booking_date) = :year" 
                 . ($month ? " AND MONTH(booking_date) = :month" : "")
                 . ($status ? " AND approval = :status" : "")
                 . " ORDER BY booking_date DESC LIMIT 10";
    
    $stmtRecent = $conn->prepare($sqlRecent);
    $stmtRecent->execute($params);
    
    $pdf->SetFont('Arial','B',10);
    $pdf->Cell(40,10,'Booking ID',1,0,'C');
    $pdf->Cell(60,10,'Date',1,0,'C');
    $pdf->Cell(40,10,'Status',1,1,'C');
    
    $pdf->SetFont('Arial','',10);
    while ($row = $stmtRecent->fetch(PDO::FETCH_ASSOC)) {
        $pdf->Cell(40,10,$row['booking_id'],1,0,'C');
        $pdf->Cell(60,10,$row['booking_date'],1,0,'C');
        $pdf->Cell(40,10,ucfirst($row['approval']),1,1,'C');
    }
    
    // Output PDF
    $pdf->Output('D', 'booking_report.pdf');
    
} catch(PDOException $e) {
    // If database error occurs, show error message
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial','B',16);
    $pdf->Cell(0,10,'Error Generating Report',0,1);
    $pdf->SetFont('Arial','',12);
    $pdf->Cell(0,10,'Database error: ' . $e->getMessage(),0,1);
    $pdf->Output();
}
?>