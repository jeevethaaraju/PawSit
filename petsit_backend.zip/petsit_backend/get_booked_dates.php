<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// Get petsitter ID from query parameters
$petsitterId = $_GET['petsitter_id'] ?? 0;

if ($petsitterId <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid petsitter ID"]);
    exit;
}

// Query to get all booked date ranges for this petsitter
$sql = "SELECT FromDate, ToDate FROM booking WHERE petSitter_ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $petsitterId);
$stmt->execute();
$result = $stmt->get_result();

$bookedDates = [];
while ($row = $result->fetch_assoc()) {
    $bookedDates[] = [
        'from' => $row['FromDate'],
        'to' => $row['ToDate']
    ];
}

echo json_encode([
    "status" => "success",
    "booked_dates" => $bookedDates
]);

$stmt->close();
$conn->close();
?>