<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["error" => "Connection failed: " . $conn->connect_error]));
}

$year = isset($_GET['year']) ? $_GET['year'] : date('Y');
$month = isset($_GET['month']) ? $_GET['month'] : null;
$status = isset($_GET['status']) ? $_GET['status'] : null;

// Get monthly data for the chart - now filtered by month if specified
$sql = "SELECT 
            MONTH(booking_date) as month,
            SUM(CASE WHEN approval = 'pending' THEN 1 ELSE 0 END) as pending,
             SUM(CASE WHEN approval = 'approved' THEN 1 ELSE 0 END) as approved,
            SUM(CASE WHEN approval = 'completed' THEN 1 ELSE 0 END) as completed,
            SUM(CASE WHEN approval = 'cancelled' THEN 1 ELSE 0 END) as cancelled
        FROM booking
        WHERE YEAR(booking_date) = ?";
        
$params = [$year];
$types = "i";

if ($month) {
    $sql .= " AND MONTH(booking_date) = ?";
    $params[] = $month;
    $types .= "i";
}

$sql .= " GROUP BY MONTH(booking_date) ORDER BY MONTH(booking_date)";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

$monthlyData = [];
while ($row = $result->fetch_assoc()) {
    $monthlyData[] = $row;
}

// Get summary counts - now properly filtered
$summarySql = "SELECT 
                SUM(CASE WHEN approval = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN approval = 'approved' THEN 1 ELSE 0 END) as approved,
                SUM(CASE WHEN approval = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN approval = 'cancelled' THEN 1 ELSE 0 END) as cancelled
              FROM booking
              WHERE YEAR(booking_date) = ?";
              
$params = [$year];
$types = "i";

if ($month) {
    $summarySql .= " AND MONTH(booking_date) = ?";
    $params[] = $month;
    $types .= "i";
}

if ($status) {
    $summarySql .= " AND approval = ?";
    $params[] = $status;
    $types .= "s";
}

$stmt = $conn->prepare($summarySql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$summaryResult = $stmt->get_result();
$summaryData = $summaryResult->fetch_assoc();

// Handle case where no summary data found
if (!$summaryData) {
    $summaryData = [
        'pending' => 0,
        'approved' => 0,
        'completed' => 0,
        'cancelled' => 0
    ];
}

// Get recent bookings
$bookingsSql = "SELECT * FROM booking WHERE YEAR(booking_date) = ?";
$params = [$year];
$types = "i";

if ($month) {
    $bookingsSql .= " AND MONTH(booking_date) = ?";
    $params[] = $month;
    $types .= "i";
}

if ($status) {
    $bookingsSql .= " AND approval = ?";
    $params[] = $status;
    $types .= "s";
}

$bookingsSql .= " ORDER BY booking_date DESC LIMIT 10";

$stmt = $conn->prepare($bookingsSql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$bookingsResult = $stmt->get_result();

$bookings = [];
while ($row = $bookingsResult->fetch_assoc()) {
    $bookings[] = $row;
}

$response = [
    'monthlyData' => $monthlyData,
    'summary' => $summaryData,
    'recentBookings' => $bookings
];

echo json_encode($response);

$conn->close();
?>