<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Database connection failed: " . $conn->connect_error
    ]);
    exit();
}

// Get owner_id from query parameter
$owner_id = isset($_GET['owner_id']) ? (int)$_GET['owner_id'] : 0;

try {
    if ($owner_id <= 0) {
        throw new Exception("Invalid owner ID");
    }

    // Prepare SQL query (without inline comments)
    $sql = "SELECT 
                complaint_id, 
                booking_id, 
                created_at,
                status,
                description,
                petSitter_ID as sitter_id,
                proof_image
            FROM complaints 
            WHERE petOwner_ID = ?
            ORDER BY created_at DESC";
    
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $owner_id);
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    $complaints = [];
    
    while ($row = $result->fetch_assoc()) {
        // Format the proof_image URL if it exists
        $proofImage = null;
        if (!empty($row['proof_image'])) {
            $proofImage = "uploads/" . basename($row['proof_image']);
        }
        
        $complaints[] = [
            "complaint_id" => $row['complaint_id'],
            "booking_id" => $row['booking_id'],
            "created_at" => $row['created_at'],
            "status" => $row['status'],
            "description" => $row['description'],
            "sitter_id" => $row['sitter_id'],
            "proof_image" => $proofImage
        ];
    }
    
    // Successful response
    echo json_encode([
        "status" => "success",
        "complaints" => $complaints
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
?>