<?php
header('Content-Type: application/json');
require_once 'connection.php';

// Get owner's address and coordinates
$ownerId = $_GET['owner_id'] ?? 0;
$stmt = $conn->prepare("SELECT Location, lat, lng FROM petowner WHERE id = ?");
$stmt->bind_param("i", $ownerId);
$stmt->execute();
$result = $stmt->get_result();
$owner = $result->fetch_assoc();

if (!$owner) {
    die(json_encode(['status' => 'error', 'message' => 'Owner not found']));
}

// Find sitters with similar address components
$query = $conn->prepare("
    SELECT id, FirstName, Location,ProfileImage, lat, lng
    FROM petsitter
WHERE status = 'active' AND (
    Location LIKE CONCAT('%', ?, '%') OR
    Location LIKE CONCAT('%', ?, '%') OR
    Location LIKE CONCAT('%', ?, '%')
)

    LIMIT 10
");

// Extract address components
$address = $owner['Location'];
$components = explode(',', $address);
$street = trim($components[0] ?? '');
$area = trim($components[2] ?? '');
$postcode = '';
preg_match('/\b(\d{5})\b/', $address, $matches);
if (!empty($matches)) $postcode = $matches[1];

$query->bind_param("sss", $street, $area, $postcode);
$query->execute();
$sitters = $query->get_result()->fetch_all(MYSQLI_ASSOC);

// Calculate distances
foreach ($sitters as &$sitter) {
    if (!empty($owner['lat']) && !empty($owner['lng']) && 
        !empty($sitter['lat']) && !empty($sitter['lng'])) {
        // Calculate actual distance if coordinates exist
        $distance = haversineDistance(
            $owner['lat'], $owner['lng'],
            $sitter['lat'], $sitter['lng']
        );
        $sitter['distance'] = round($distance, 1) . ' km away';
        $sitter['distance_value'] = $distance;
    } else {
        // Fallback to text similarity if no coordinates
        similar_text($owner['Location'], $sitter['Location'], $percent);
        $sitter['match_score'] = round($percent, 2);
        $estimatedDistance = max(0, 20 - ($percent / 5)); // Convert % to km
        $sitter['distance'] = '~' . round($estimatedDistance, 1) . ' km away';
        $sitter['distance_value'] = $estimatedDistance;
    }
}

// Sort by distance (nearest first)
usort($sitters, function($a, $b) {
    return $a['distance_value'] <=> $b['distance_value'];
});

// Return results
echo json_encode([
    'status' => 'success',
    'sitters' => array_slice($sitters, 0, 10)
]);

$conn->close();

// Haversine formula for distance calculation
function haversineDistance($lat1, $lng1, $lat2, $lng2) {
    $earthRadius = 6371; // km

    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);

    $a = sin($dLat/2) * sin($dLat/2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
         sin($dLng/2) * sin($dLng/2);
    $c = 2 * atan2(sqrt($a), sqrt(1-$a));

    return $earthRadius * $c;
}
?>