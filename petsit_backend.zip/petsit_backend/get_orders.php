<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get owner_id from query parameters
$ownerId = isset($_GET['owner_id']) ? (int)$_GET['owner_id'] : 0;

if ($ownerId <= 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid owner ID"
    ]);
    exit;
}

// Prepare and execute query - now including approval status
$stmt = $conn->prepare("
    SELECT 
        booking_id,
        service_name,
        FromDate,
        ToDate,
        FromTime,
        ToTime,
        Pets,
        Price,
        TotalPrice,
        PayMethod,
        booking_date,
        petSitter_ID,
        approval
    FROM booking 
    WHERE petOwner_ID = ?
    ORDER BY booking_date DESC
");

$stmt->bind_param("i", $ownerId);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    // Format dates if needed
    $row['FromDate'] = date("d M Y", strtotime($row['FromDate']));
    $row['ToDate'] = date("d M Y", strtotime($row['ToDate']));
    $row['booking_date'] = date("d M Y H:i", strtotime($row['booking_date']));
    
    // Set default status if null
    if ($row['approval'] === null) {
        $row['approval'] = 'pending';
    }
    
    $orders[] = $row;
}

if (count($orders) > 0) {
    echo json_encode([
        "status" => "success",
        "orders" => $orders
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "message" => "No orders found",
        "orders" => []
    ]);
}

$stmt->close();
$conn->close();
?>