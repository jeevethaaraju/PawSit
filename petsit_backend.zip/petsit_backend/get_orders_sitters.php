<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error",
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Handle POST request for approval updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['booking_id']) || !isset($data['approval_status'])) {
        echo json_encode([
            "status" => "error",
            "message" => "Missing required parameters"
        ]);
        exit;
    }
    
    $bookingId = (int)$data['booking_id'];
    $approvalStatus = $conn->real_escape_string($data['approval_status']);
    
    $stmt = $conn->prepare("UPDATE booking SET approval = ? WHERE booking_id = ?");
    $stmt->bind_param("si", $approvalStatus, $bookingId);
    
    if ($stmt->execute()) {
        echo json_encode([
            "status" => "success",
            "message" => "Booking status updated successfully"
        ]);
    } else {
        echo json_encode([
            "status" => "error",
            "message" => "Failed to update booking status"
        ]);
    }
    
    $stmt->close();
    $conn->close();
    exit;
}

// Original GET request handling for fetching orders
$sitterId = isset($_GET['sitter_id']) ? (int)$_GET['sitter_id'] : 0;

if ($sitterId <= 0) {
    echo json_encode([
        "status" => "error",
        "message" => "Invalid owner ID"
    ]);
    exit;
}

// Prepare and execute query
$stmt = $conn->prepare("
    SELECT 
        booking_id,
        service_name,
        FromDate,
        ToDate,
        FromTime,
        ToTime,
        Pets,
        PetTypes,
        Price,
        TotalPrice,
        PayMethod,
        booking_date,
        petOwner_ID,
        approval
    FROM booking 
    WHERE petSitter_ID = ?
    ORDER BY booking_date DESC
");

$stmt->bind_param("i", $sitterId);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    // Format dates if needed
    $row['FromDate'] = date("d M Y", strtotime($row['FromDate']));
    $row['ToDate'] = date("d M Y", strtotime($row['ToDate']));
    $row['booking_date'] = date("d M Y H:i", strtotime($row['booking_date']));
    
    $orders[] = $row;
}

if (count($orders) > 0) {
    echo json_encode([
        "status" => "success",
        "orders" => $orders
    ]);
} else {
    echo json_encode([
        "status" => "success",
        "message" => "No orders found",
        "orders" => []
    ]);
}

$stmt->close();
$conn->close();
?>