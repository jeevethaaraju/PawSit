<?php
header("Content-Type: application/json; charset=UTF-8");

// Database connection
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(array("error" => "Connection failed: " . $conn->connect_error)));
}

// Get the pet ID from the request
$petId = isset($_GET['pet_id']) ? intval($_GET['pet_id']) : 0;

if ($petId <= 0) {
    die(json_encode(array("error" => "Invalid pet ID")));
}

// Prepare and execute query - now selecting petType and petBreed too
// Added status = 'active' condition to only select active pets
$stmt = $conn->prepare("SELECT id, petName, petType, petBreed, petSize, petGender, petBirthDate, petImage 
                        FROM pet 
                        WHERE id = ? AND status = 'active'");
$stmt->bind_param("i", $petId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(array(
        "success" => true,
        "pet" => array(
            "id" => $row['id'],
            "petName" => $row['petName'],
            "petType" => $row['petType'],
            "petBreed" => $row['petBreed'],
            "petSize" => $row['petSize'],
            "petGender" => $row['petGender'],
            "petBirthDate" => $row['petBirthDate'],
            "petImage" => $row['petImage']
            // Add other fields here if needed
        )
    ));
} else {
    echo json_encode(array("error" => "Active pet not found"));
}

$stmt->close();
$conn->close();
?>