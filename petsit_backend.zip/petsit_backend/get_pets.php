<?php
header('Content-Type: application/json');
session_start();

// Verify session
if (!isset($_SESSION['petOwner']) || !isset($_SESSION['petOwner']['petOwnerId'])) {
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

// Get owner ID from request
$ownerId = isset($_GET['owner_id']) ? intval($_GET['owner_id']) : 0;

// Verify requested owner matches session owner
if ($ownerId !== $_SESSION['petOwner']['petOwnerId']) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
    exit;
}

// Database connection
$conn = new mysqli("localhost", "root", "", "petsit");
if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

// Fetch pets
$stmt = $conn->prepare("SELECT id, petName, petType, petBreed, petSize, petGender, petBirthDate, petImage FROM pet WHERE petOwner_ID = ? AND status = 'active'");
$stmt->bind_param("i", $ownerId);
$stmt->execute();
$result = $stmt->get_result();

$pets = [];
while ($row = $result->fetch_assoc()) {
    $pets[] = $row;
}

echo json_encode([
    'status' => 'success',
    'pets' => $pets
]);

$stmt->close();
$conn->close();
?>