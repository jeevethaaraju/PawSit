<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

$lat = $_GET['lat'];
$lng = $_GET['lng'];
$ownerId = $_GET['owner_id'];

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// Get owner's location
$ownerSql = "SELECT lat, lng FROM petowner WHERE id = ?";
$ownerStmt = $conn->prepare($ownerSql);
$ownerStmt->bind_param("i", $ownerId);
$ownerStmt->execute();
$ownerResult = $ownerStmt->get_result();

if ($ownerResult->num_rows === 0) {
    die(json_encode(["status" => "error", "message" => "Owner not found"]));
}

$owner = $ownerResult->fetch_assoc();
$ownerLat = $owner['lat'];
$ownerLng = $owner['lng'];
$ownerStmt->close();

// Get complete service details with distance calculation
$sql = "SELECT s.*, p.*, 
               (6371 * ACOS(
                   COS(RADIANS(?)) * COS(RADIANS(p.lat)) * 
                   COS(RADIANS(p.lng) - RADIANS(?)) + 
                   SIN(RADIANS(?)) * SIN(RADIANS(p.lat))
               )) AS distance
        FROM petsitter p
        JOIN services s ON p.id = s.petsitter_id
        WHERE p.lat = ? AND p.lng = ? 
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ddddd", $ownerLat, $ownerLng, $ownerLat, $lat, $lng);
$stmt->execute();
$result = $stmt->get_result();

$response = [];
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Include all required fields from both tables
    $response = [
        "id" => $row["id"],
        "service_name" => $row["service_name"],
        "summ" => $row["summ"],
        "numofpets" => $row["numofpets"],
        "accept_pet" => $row["accept_pet"],
        "accept_petsize" => $row["accept_petsize"],
        "unsupervised" => $row["unsupervised"],
        "potty" => $row["potty"],
        "walks" => $row["walks"],
        "home" => $row["home"],
        "transport" => $row["transport"],
        "price" => $row["price"],
        "service" => $row["service"],
        "picture" => $row["picture"],
        "location" => $row["Location"], // From petsitter table
        "phone" => $row["Phone_Number"], // From petsitter table
        "profile_image" => $row["ProfileImage"], // From petsitter table
        "distance" => round($row["distance"], 1)
    ];
} else {
    $response["error"] = "No service found for this pet sitter";
}

$stmt->close();
$conn->close();

echo json_encode($response);
?>