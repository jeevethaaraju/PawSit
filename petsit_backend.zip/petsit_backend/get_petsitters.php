<?php
require_once 'connection.php';

$query = "SELECT id, FirstName, Location, lat, lng FROM petsitter";
$result = mysqli_query($conn, $query);

$petsitter = array();
while($row = mysqli_fetch_assoc($result)) {
    $petsitter[] = $row;
}

header('Content-Type: application/json');
echo json_encode($petsitter);
?>