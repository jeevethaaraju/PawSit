<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Headers: Content-Type");

require_once 'connection.php'; // Database connection file
require_once 'config.php'; // Configuration file with BASE_URL

// Get owner ID from GET parameters
$ownerId = isset($_GET['owner_id']) ? intval($_GET['owner_id']) : 0;

if ($ownerId <= 0) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid owner ID']);
    exit;
}

// Database query
$query = "SELECT id, petName, petType, petBreed, petSize, petGender, 
          DATE_FORMAT(petBirthDate, '%Y-%m-%d') as petBirthDate, 
          petImage 
          FROM pet 
          WHERE petOwner_ID = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $ownerId);
$stmt->execute();
$result = $stmt->get_result();

$pets = [];
while ($row = $result->fetch_assoc()) {
    // Convert image path to full URL if stored as relative path
    if (!empty($row['petImage']) && !filter_var($row['petImage'], FILTER_VALIDATE_URL)) {
        $row['petImage'] = BASE_URL . 'uploads/' . $row['petImage'];
    }
    $pets[] = $row;
}

echo json_encode([
    'status' => 'success',
    'pets' => $pets
]);

$stmt->close();
$conn->close();
?>