<?php
header('Content-Type: application/json');

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "success" => false,
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get input data
$data = json_decode(file_get_contents('php://input'), true);
$userId = $data['user_id'] ?? '';

if (empty($userId)) {
    die(json_encode([
        "success" => false,
        "message" => "User ID is required"
    ]));
}

// Query to get user profile
$sql = "SELECT 
          UserID,
          FirstName as first_name,
          LastName as last_name,
          Email,
          Gender,
          DATE_FORMAT(BirthDate, '%Y-%m-%d') as birth_date,
          ProfileImage
        FROM petowners 
        WHERE UserID = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $userId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo json_encode([
        "success" => true,
        "user" => [
            "user_id" => $user['UserID'],
            "first_name" => $user['first_name'],
            "last_name" => $user['last_name'],
            "email" => $user['Email'],
            "gender" => $user['Gender'],
            "birth_date" => $user['birth_date'],
            "profile_image" => $user['ProfileImage']
        ]
    ]);
} else {
    echo json_encode([
        "success" => false,
        "message" => "User not found"
    ]);
}

$stmt->close();
$conn->close();
?>