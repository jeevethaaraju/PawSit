<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode([
        "status" => "error", 
        "message" => "Connection failed: " . $conn->connect_error
    ]));
}

// Get the petsitter ID from the request
$petsitterId = isset($_GET['petsitter_id']) ? intval($_GET['petsitter_id']) : 0;

if ($petsitterId <= 0) {
    echo json_encode([
        "status" => "error", 
        "message" => "Valid pet sitter ID is required"
    ]);
    exit;
}

// Prepare and execute the query with all image fields
$query = "
    SELECT 
        id,
        service_name, 
        summ, 
        numofpets, 
        accept_pet,
        accept_petsize, 
        unsupervised,
        potty, 
        walks, 
        home, 
        transport, 
        price,  
        service, 
        picture1,
        picture2,
        picture3,
        petsitter_id 
    FROM services 
    WHERE petsitter_id = ?
    LIMIT 1
";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode([
        "status" => "error", 
        "message" => "Prepare failed: " . $conn->error
    ]);
    exit;
}

$stmt->bind_param("i", $petsitterId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $service = $result->fetch_assoc();
    
    // Process images into an array
    $pictures = [];
    for ($i = 1; $i <= 3; $i++) {
        $field = "picture$i";
        if (!empty($service[$field])) {
            $pictures[] = $service[$field];
            unset($service[$field]); // Remove individual fields
        }
    }
    
    // Process the data for better client-side handling
    $response = [
        "status" => "success",
        "service" => [
            "id" => $service['id'],
            "service_name" => $service['service_name'],
            "description" => $service['summ'],
            "numofpets" => $service['numofpets'],
            "accept_pet" => $service['accept_pet'],
            "accept_petsize" => $service['accept_petsize'],
            "unsupervised" => $service['unsupervised'],
            "potty" => $service['potty'],
            "walks" => $service['walks'],
            "home" => $service['home'],
            "transport" => $service['transport'],
            "price" => $service['price'],
            "service" => $service['service'],
            "pictures" => $pictures, // Array of image paths
            "petsitter_id" => $service['petsitter_id']
        ]
    ];
    
    echo json_encode($response);
} else {
    echo json_encode([
        "status" => "error", 
        "message" => "No service found for this pet sitter"
    ]);
}

$stmt->close();
$conn->close();
?>