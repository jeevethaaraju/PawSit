<?php
include('config.php');
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $data = json_decode(file_get_contents("php://input"), true);
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);

    $stmt = $conn->prepare("SELECT FirstName, LastName, Gender, Email, Birth_Date, Phone_Number, 
                                   ProfileImage, Location, lat, lng
                            FROM petsitter 
                            WHERE Email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        $profileImage = $user['ProfileImage'];
        if (!empty($profileImage)) {
            $cleanImage = trim($profileImage, "/ \t\n\r\0\x0B");
            $user['ProfileImage'] = $cleanImage;
            $user['ProfileImageUrl'] = BASE_URL . $cleanImage;
        } else {
            $user['ProfileImage'] = '';
            $user['ProfileImageUrl'] = '';
        }

        echo json_encode([
            'status' => 'success',
            'data' => $user
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'User not found'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>