<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
date_default_timezone_set('Asia/Kuala_Lumpur');


include 'connection.php';

// Check if connection was successful
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(array("message" => "Database connection failed: " . $conn->connect_error));
    exit;
}

$sitterId = isset($_GET['sitter_id']) ? intval($_GET['sitter_id']) : 0;

if ($sitterId <= 0) {
    http_response_code(400);
    echo json_encode(array("message" => "Invalid sitter ID."));
    exit;
}

try {
    // Calculate date range (today + next 2 days)
    $today = date('Y-m-d');
    $endDate = date('Y-m-d', strtotime('+2 days'));

    $query = "
        SELECT 
            b.booking_id,
            b.service_name,
            b.FromDate,
            b.FromTime,
            b.ToTime,
            b.approval,
            po.id as owner_id,
            po.FirstName,
            po.LastName,
            po.Email,
            po.ProfileImage
        FROM 
            booking b
        JOIN 
            petowner po ON b.petOwner_ID = po.id
        WHERE 
            b.petSitter_ID = ?
            AND b.FromDate BETWEEN ? AND ?
            AND b.approval = 'approved'
        ORDER BY 
            b.FromDate ASC, b.FromTime ASC";

    $stmt = $conn->prepare($query);
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("iss", $sitterId, $today, $endDate);
    
    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }
    
    $result = $stmt->get_result();
    if (!$result) {
        throw new Exception("Get result failed: " . $stmt->error);
    }

    $upcomingBookings = array();
    while ($row = $result->fetch_assoc()) {
        $fromDate = new DateTime($row['FromDate']);
        $today = new DateTime();
        $tomorrow = new DateTime('tomorrow');
        
        $dateDisplay = '';
        if ($fromDate->format('Y-m-d') == $today->format('Y-m-d')) {
            $dateDisplay = 'Today, ' . date('g:i A', strtotime($row['FromTime']));
        } elseif ($fromDate->format('Y-m-d') == $tomorrow->format('Y-m-d')) {
            $dateDisplay = 'Tomorrow, ' . date('g:i A', strtotime($row['FromTime']));
        } else {
            $dateDisplay = date('D, M j', strtotime($row['FromDate'])) . ', ' . date('g:i A', strtotime($row['FromTime']));
        }
        
        // Ensure ProfileImage has proper path
        $profileImage = $row['ProfileImage'];
        if (!empty($profileImage) && !str_starts_with($profileImage, 'http')) {
            $profileImage = $profileImage;
        }
        
        $upcomingBookings[] = array(
            'booking_id' => $row['booking_id'],
            'client_name' => $row['FirstName'] . ' ' . $row['LastName'],
            'service' => $row['service_name'],
            'date_display' => $dateDisplay,
            'email' => $row['Email'],
            'profile_image' => $profileImage
        );
    }

    if (empty($upcomingBookings)) {
        http_response_code(200); // Changed from 404 to 200 since empty result is valid
        echo json_encode(array("message" => "No upcoming bookings found."));
    } else {
        echo json_encode($upcomingBookings);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array("message" => "Server error: " . $e->getMessage()));
} finally {
    if (isset($stmt)) {
        $stmt->close();
    }
    $conn->close();
}
?>