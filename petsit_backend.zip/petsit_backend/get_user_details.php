<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
require_once 'config.php'; // Add this at the top
$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    // Establish a database connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get input data
    $data = json_decode(file_get_contents("php://input"), true);
    $email = filter_var($data['email'], FILTER_SANITIZE_EMAIL);

    // Log the received email (for debugging)
    error_log("Email received: " . $email);

    // Fetch user data from the petowner table
    $stmt = $conn->prepare("SELECT FirstName, LastName, Gender, Email, Birth_Date, Phone_Number, Location, ProfileImage FROM petowner WHERE Email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    // Fetch user data
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Clean the image path (remove leading slashes)
        $cleanImage = ltrim($user['ProfileImage'], '/\\');
        
        // Build the full image URL
        $imagePath = BASE_URL . $cleanImage; // Full URL for the image
        
        // Return both the relative path and full URL
        $user['ProfileImage'] = $cleanImage;  // Relative image path (to be saved in SharedPreferences)
        $user['ProfileImageUrl'] = $imagePath;  // Full URL for the image

        echo json_encode([
            'status' => 'success',
            'data' => $user
        ]);
    } else {
        echo json_encode([
            'status' => 'error',
            'message' => 'User not found'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>
