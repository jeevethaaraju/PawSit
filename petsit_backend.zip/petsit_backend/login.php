<?php
header('Content-Type: application/json');
session_start();

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Database connection
$conn = new mysqli("localhost", "root", "", "petsit");

if ($conn->connect_error) {
    echo json_encode([
        "success" => false, 
        "message" => "Connection failed: " . $conn->connect_error
    ]);
    exit;
}

// Validate input
if (empty($data['Email']) || empty($data['password'])) {
    echo json_encode([
        "success" => false, 
        "message" => "Email and password are required"
    ]);
    exit;
}

$email = $conn->real_escape_string($data['Email']);
$password = $data['password'];

// Prepare statement for petowner table only
$stmt = $conn->prepare("SELECT * FROM petowner WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['Password'])) {
        // Store pet owner data in session
        $_SESSION['petOwner'] = [
            'petOwnerId' => $row['id'],
            'firstName' => $row['FirstName'],
            'lastName' => $row['LastName'],
            'email' => $row['Email'],
            'profileImage' => $row['ProfileImage'] ?? '',
            'gender' => $row['Gender'] ?? '',
            'birthDate' => $row['Birth_Date'] ?? '',
            'role' => 'petowner'
        ];
        
        // Generate session token
        $session_token = session_id();
        
        echo json_encode([
            "success" => true,
            "petOwner" => $_SESSION['petOwner'],
            "session_token" => $session_token
        ]);
        exit;
    }
}

// If we get here, authentication failed
echo json_encode([
    "success" => false, 
    "message" => "Invalid email or password"
]);

$conn->close();
?>