<?php
header('Content-Type: text/plain');

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$email = $_POST['Email'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($email) || empty($password)) {
    die("Email and password are required");
}

// Check in petowner table
$stmt = $conn->prepare("SELECT Password FROM petsitter WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['Password'])) {
        echo "success";
        exit;
    }
}

// Check in petsitter table if not found in petsitter
$stmt = $conn->prepare("SELECT Password FROM petsitter WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['Password'])) {
        echo "success";
        exit;
    }
}

echo "Invalid email or password";
$conn->close();
?>