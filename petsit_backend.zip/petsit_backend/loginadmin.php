<?php
header('Content-Type: application/json');
session_start();

// Database configuration
$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get JSON input
    $json = file_get_contents('php://input');
    $data = json_decode($json, true);

    // Validate input
    if (empty($data['Email']) || empty($data['Password'])) {
        echo json_encode([
            "success" => false, 
            "message" => "Email and password are required"
        ]);
        exit;
    }

    // Check admin credentials
    $stmt = $conn->prepare("SELECT id, FirstName as name, Email as email, Password FROM petadmin WHERE Email = :email");
    $stmt->bindParam(':email', $data['Email']);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Verify password with bcrypt hash
        if (password_verify($data['Password'], $admin['Password'])) {
            // Set session
            $_SESSION['admin'] = [
                'id' => $admin['id'],
                'name' => $admin['name'],
                'email' => $admin['email'],
                'logged_in' => true
            ];
            
            echo json_encode([
                "success" => true,
                "message" => "Login successful",
                "admin" => [
                    "id" => $admin['id'],
                    "name" => $admin['name'],
                    "email" => $admin['email']
                ]
            ]);
        } else {
            echo json_encode([
                "success" => false, 
                "message" => "Invalid credentials"
            ]);
        }
    } else {
        echo json_encode([
            "success" => false, 
            "message" => "Admin not found"
        ]);
    }
} catch(PDOException $e) {
    echo json_encode([
        "success" => false, 
        "message" => "Database error: " . $e->getMessage()
    ]);
}
?>