<?php
header('Content-Type: application/json');
session_start();

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Database connection
$conn = new mysqli("localhost", "root", "", "petsit");

if ($conn->connect_error) {
    echo json_encode([
        "success" => false, 
        "message" => "Connection failed: " . $conn->connect_error
    ]);
    exit;
}

// Validate input
if (empty($data['Email']) || empty($data['password'])) {
    echo json_encode([
        "success" => false, 
        "message" => "Email and password are required"
    ]);
    exit;
}

$email = $conn->real_escape_string($data['Email']);
$password = $data['password'];

// Prepare statement for petsitter table
$stmt = $conn->prepare("SELECT * FROM petsitter WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // First check if account is inactive
    if (isset($row['status']) && $row['status'] === 'inactive') {
        echo json_encode([
            "success" => false, 
            "message" => "Your account is no longer active"
        ]);
        exit;
    }
    
    // Then verify password
    if (password_verify($password, $row['Password'])) {
        // Store pet sitter data in session
        $_SESSION['petSitter'] = [
            'petSitterId' => $row['id'],
            'firstName' => $row['FirstName'],
            'lastName' => $row['LastName'],
            'email' => $row['Email'],
            'profileImage' => $row['ProfileImage'] ?? '',
            'gender' => $row['Gender'] ?? '',
            'birthDate' => $row['Birth_Date'] ?? '',
            'role' => 'petsitter',
            'status' => $row['status'] ?? 'active' // Include status in session
        ];
        
        // Generate session token
        $session_token = session_id();
        
        echo json_encode([
            "success" => true,
            "petSitter" => $_SESSION['petSitter'],
            "session_token" => $session_token
        ]);
        exit;
    }
}

// If we get here, authentication failed
echo json_encode([
    "success" => false, 
    "message" => "Invalid email or password"
]);

$conn->close();
?>