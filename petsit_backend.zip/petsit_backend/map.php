<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// Query to get active pet sitter locations
$sql = "SELECT lat, lng FROM petsitter 
        WHERE lat IS NOT NULL 
        AND lng IS NOT NULL 
        AND status = 'active'";  // Added status condition

$result = $conn->query($sql);

$locations = array();
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $locations[] = array(
            "lat" => (float)$row["lat"],
            "lng" => (float)$row["lng"]
        );
    }
}

$conn->close();

echo json_encode($locations);
?>