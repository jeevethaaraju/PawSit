<?php
include 'connection.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$query = "SELECT service_name, price, accept_pet FROM services WHERE id = $id";
$result = mysqli_query($conn, $query);

if ($row = mysqli_fetch_assoc($result)) {
    echo json_encode($row);
} else {
    echo json_encode(["error" => "Not found"]);
}
?>
