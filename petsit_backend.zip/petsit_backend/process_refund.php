<?php
header('Content-Type: application/json');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'connection.php';
$response = ["success" => false, "message" => "", "amount_refunded" => 0];

// Get request data
$requestData = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($requestData['booking_id'])) {
    $bookingId = (int)$requestData['booking_id'];
    error_log("=== Processing refund for booking ID: $bookingId ===");

    $conn->begin_transaction();

    try {
        // 1. Get booking details
        $getBooking = $conn->prepare("SELECT booking_id, petOwner_ID, TotalPrice, approval 
                                   FROM booking 
                                   WHERE booking_id = ?");
        $getBooking->bind_param("i", $bookingId);
        $getBooking->execute();
        $booking = $getBooking->get_result()->fetch_assoc();
        $getBooking->close();

        if (!$booking) {
            throw new Exception("Booking $bookingId not found");
        }

        // Check if already cancelled
        if ($booking['approval'] === 'cancelled') {
            throw new Exception("Booking already cancelled");
        }

        $ownerId = (int)$booking['petOwner_ID'];
        
        // Sanitize price (remove currency symbols, etc.)
        $cleanPrice = preg_replace('/[^0-9.]/', '', $booking['TotalPrice']);
        $amount = floatval($cleanPrice);
        
        if ($amount <= 0) {
            throw new Exception("Invalid amount to refund");
        }

        // 2. Update booking status to cancelled
        $updateBooking = $conn->prepare("UPDATE booking 
                                       SET approval = 'cancelled' 
                                       WHERE booking_id = ?");
        $updateBooking->bind_param("i", $bookingId);
        if (!$updateBooking->execute()) {
            throw new Exception("Failed to cancel booking: " . $updateBooking->error);
        }
        $updateBooking->close();

        // 3. Refund to owner's wallet
        $updateWallet = $conn->prepare("UPDATE petowner 
                                     SET WalletBalance = WalletBalance + ? 
                                     WHERE id = ?");
        $updateWallet->bind_param("di", $amount, $ownerId);
        if (!$updateWallet->execute()) {
            throw new Exception("Failed to process refund: " . $updateWallet->error);
        }
        $updateWallet->close();

        $conn->commit();

        $response = [
            "success" => true,
            "message" => "Successfully refunded RM" . number_format($amount, 2) . " to owner $ownerId",
            "amount_refunded" => $amount
        ];

    } catch (Exception $e) {
        $conn->rollback();
        $response["message"] = "Error: " . $e->getMessage();
        error_log("REFUND FAILED: " . $e->getMessage());
    }
} else {
    $response["message"] = "Invalid request. Booking ID required.";
}

echo json_encode($response, JSON_PRETTY_PRINT);
$conn->close();