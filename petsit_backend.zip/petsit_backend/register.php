<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $result = ["success" => false, "message" => "Initial error"];

    try {
        $required = ['FirstName', 'LastName', 'Email', 'password', 'birth_date','Phone_Number','Location', 'Gender', 'Role'];
        foreach ($required as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("$field is required");
            }
        }

        $FirstName = htmlspecialchars(trim($_POST['FirstName']));
        $LastName = htmlspecialchars(trim($_POST['LastName']));
        $Email = filter_var(trim($_POST['Email']), FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $Gender = $_POST['Gender'];
        $Role = $_POST['Role'];
        $birth_date = date('Y-m-d', strtotime($_POST['birth_date']));
        $Phone_Number = $_POST['Phone_Number'];
        $Location = $_POST['Location'];
        $ProfileImage = isset($_POST['ProfileImage']) ? $_POST['ProfileImage'] : '';
        $lat = isset($_POST['lat']) ? floatval($_POST['lat']) : null;
        $lng = isset($_POST['lng']) ? floatval($_POST['lng']) : null;
        
        // New fields for bank details
        $bank = isset($_POST['Bank']) ? htmlspecialchars(trim($_POST['Bank'])) : '';
        $accountNumber = isset($_POST['AccountNumber']) ? trim($_POST['AccountNumber']) : '';

        if (!filter_var($Email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Additional validation for petsitters
        if ($Role == 'petsitter') {
            if (empty($bank)) {
                throw new Exception("Bank selection is required for petsitters");
            }
            if (empty($accountNumber)) {
                throw new Exception("Account number is required for petsitters");
            }
            if (!preg_match('/^[0-9]{10,20}$/', $accountNumber)) {
                throw new Exception("Account number must be 10-20 digits");
            }
        }

        $passwordHash = password_hash($password, PASSWORD_DEFAULT);
        require_once 'connection.php';

        $table = ($Role == 'petsitter') ? 'petsitter' : 'petowner';

        if ($Role == 'petsitter') {
            $sql = "INSERT INTO $table (
                        FirstName, 
                        LastName, 
                        Email, 
                        Password, 
                        birth_date,
                        Phone_Number,
                        Location, 
                        Gender, 
                        Role, 
                        ProfileImage,
                        lat,
                        lng,
                        bank,
                        account_number
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param(
                $stmt, 
                "ssssssssssddss",
                $FirstName, 
                $LastName, 
                $Email, 
                $passwordHash, 
                $birth_date,
                $Phone_Number,
                $Location, 
                $Gender, 
                $Role, 
                $ProfileImage,
                $lat,
                $lng,
                $bank,
                $accountNumber
            );
        } else {
            $sql = "INSERT INTO $table (
                        FirstName, 
                        LastName, 
                        Email, 
                        Password, 
                        birth_date,
                        Phone_Number,
                        Location, 
                        Gender, 
                        Role, 
                        ProfileImage,
                        lat,
                        lng
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param(
                $stmt, 
                "ssssssssssdd",
                $FirstName, 
                $LastName, 
                $Email, 
                $passwordHash, 
                $birth_date,
                $Phone_Number,
                $Location, 
                $Gender, 
                $Role, 
                $ProfileImage,
                $lat,
                $lng
            );
        }

        if (mysqli_stmt_execute($stmt)) {
            $result["success"] = true;
            $result["message"] = "Registration successful as $Role";
            $result["user_id"] = mysqli_insert_id($conn);
        } else {
            if (mysqli_errno($conn) == 1062) {
                throw new Exception("Email already exists");
            } else {
                throw new Exception("Database error: " . mysqli_error($conn));
            }
        }

        mysqli_stmt_close($stmt);
        mysqli_close($conn);

    } catch (Exception $e) {
        $result["message"] = $e->getMessage();
        if (isset($conn) && $conn) {
            mysqli_close($conn);
        }
    }

    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
} else {
    $result = [
        "success" => false,
        "message" => "Invalid request method"
    ];
    header('Content-Type: application/json');
    echo json_encode($result);
    exit;
}
?>