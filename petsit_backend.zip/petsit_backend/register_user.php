<?php
// Set up database connection
$conn = new mysqli('localhost', 'root', '', 'medicine_reco'); // Change the database details if needed

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form data is received via POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the POST data from the request
    $full_name = $_POST['full_name'] ?? '';  // Null coalescing to handle unset keys
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Validate the input (Make sure no fields are empty)
    if (empty($full_name) || empty($email) || empty($password)) {
        echo "Missing required fields (full_name, email, or password).";
        exit;
    }

    // Hash the password (important for security)
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare the SQL query to insert the data into the 'users' table
    $sql = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the parameters
        $stmt->bind_param("sss", $full_name, $email, $hashedPassword);

        // Execute the query
        if ($stmt->execute()) {
            echo "Registration successful!";
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the prepared statement
        $stmt->close();
    } else {
        echo "Error preparing the SQL statement: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
} else {
    echo "Invalid request method. Expected POST.";
}
?>
