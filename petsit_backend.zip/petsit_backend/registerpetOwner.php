<?php
// Database connection
$servername = "localhost";  // Database server, usually 'localhost'
$username = "root";         // Database username
$password = "";             // Database password (if any, leave blank for default)
$dbname = "petsit";         // Name of the database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data from the Android app
$firstName = isset($_POST['FirstName']) ? $_POST['FirstName'] : '';
$lastName = isset($_POST['LastName']) ? $_POST['LastName'] : '';
$email = isset($_POST['Email']) ? $_POST['Email'] : '';
$password = isset($_POST['Password']) ? $_POST['Password'] : '';
$birthDate = isset($_POST['birth_date']) ? $_POST['birth_date'] : '';
$gender = isset($_POST['Gender']) ? $_POST['Gender'] : '';
$role = isset($_POST['Role']) ? $_POST['Role'] : '';

// Check if all required fields are filled
if (empty($firstName) || empty($lastName) || empty($email) || empty($password) || empty($birthDate) || empty($gender) || empty($role)) {
    echo "Error: Missing required fields.";
    exit();
}

// Sanitize the input data to prevent SQL injection
$firstName = $conn->real_escape_string($firstName);
$lastName = $conn->real_escape_string($lastName);
$email = $conn->real_escape_string($email);
$password = $conn->real_escape_string($password);
$birthDate = $conn->real_escape_string($birthDate);
$gender = $conn->real_escape_string($gender);
$role = $conn->real_escape_string($role);

// Hash the password for security
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Insert data into the database
$sql = "INSERT INTO petowner (FirstName, LastName, Email, Password, birth_date, Gender, Role) 
        VALUES ('$firstName', '$lastName', '$email', '$hashedPassword', '$birthDate', '$gender', '$role')";

// Execute the query and check if the insertion is successful
if ($conn->query($sql) === TRUE) {
    echo "Success";  // This will be returned to the Android app if the insert is successful
} else {
    echo "Error: " . $conn->error;  // Display specific error if the query fails
}

// Close the connection
$conn->close();
?>
