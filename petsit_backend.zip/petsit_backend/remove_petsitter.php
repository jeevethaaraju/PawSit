<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'connection.php';
$response = ["success" => false, "message" => "", "refunds_attempted" => []];

$requestData = json_decode(file_get_contents('php://input'), true) ?? $_POST;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($requestData['petSitterId'])) {
    $petSitterId = (int)$requestData['petSitterId'];
    $complaintBookingId = isset($requestData['complaintBookingId']) ? (int)$requestData['complaintBookingId'] : null;

    error_log("=== Processing petsitter deactivation ID: $petSitterId ===");

    $conn->begin_transaction();

    try {
        // 1. Verify petsitter exists and is active
        $checkSitter = $conn->prepare("SELECT status FROM petsitter WHERE id = ?");
        $checkSitter->bind_param("i", $petSitterId);
        $checkSitter->execute();
        $sitter = $checkSitter->get_result()->fetch_assoc();
        $checkSitter->close();

        if (!$sitter) {
            throw new Exception("Petsitter not found");
        }
        if ($sitter['status'] === 'inactive') {
            throw new Exception("Petsitter already inactive");
        }

        // 2. Select bookings
        $getBookings = $conn->prepare("
            SELECT booking_id, petOwner_ID, TotalPrice, approval, FromDate 
            FROM booking 
            WHERE petSitter_Id = ? 
              AND (
                  booking_id = ? OR FromDate > CURDATE()
              )
              AND approval != 'cancelled'
        ");
        $getBookings->bind_param("ii", $petSitterId, $complaintBookingId);
        $getBookings->execute();
        $bookings = $getBookings->get_result();

        $bookingsToCancel = [];
        $refundData = [];

        while ($booking = $bookings->fetch_assoc()) {
            $bookingId = $booking['booking_id'];
            $ownerId = (int)$booking['petOwner_ID'];
            $approval = $booking['approval'];
            $fromDate = $booking['FromDate'];
            $isFuture = (strtotime($fromDate) > strtotime(date("Y-m-d")));
            $isComplaint = ($bookingId == $complaintBookingId);

            // Apply rules
            if ($approval === 'rejected') continue;
            if ($approval === 'completed' && !$isComplaint) continue;
            if (!$isComplaint && !$isFuture) continue;

            // Cancel booking
            $bookingsToCancel[] = $bookingId;

            // Prepare refund amount
            $amount = (float)preg_replace('/[^0-9.]/', '', $booking['TotalPrice']);
            if ($amount > 0) {
                if (!isset($refundData[$ownerId])) {
                    $refundData[$ownerId] = 0;
                }
                $refundData[$ownerId] += $amount;
            }
        }
        $getBookings->close();

        // 3. Cancel bookings
        if (!empty($bookingsToCancel)) {
            $placeholders = implode(',', array_fill(0, count($bookingsToCancel), '?'));
            $types = str_repeat('i', count($bookingsToCancel));
            $stmt = $conn->prepare("UPDATE booking SET approval = 'cancelled' WHERE booking_id IN ($placeholders)");
            $stmt->bind_param($types, ...$bookingsToCancel);
            $stmt->execute();
            $stmt->close();
        }

        // 4. Refund owners
        foreach ($refundData as $ownerId => $amount) {
            $refundStmt = $conn->prepare("UPDATE petowner SET WalletBalance = WalletBalance + ? WHERE id = ?");
            $refundStmt->bind_param("di", $amount, $ownerId);
            $refundStmt->execute();
            $refundStmt->close();
        }

        // 5. Deactivate petsitter
        $deactivate = $conn->prepare("UPDATE petsitter SET status = 'inactive' WHERE id = ?");
        $deactivate->bind_param("i", $petSitterId);
        $deactivate->execute();
        $deactivate->close();

        $conn->commit();

        $response = [
            "success" => true,
            "message" => "Petsitter deactivated successfully",
            "bookings_cancelled" => count($bookingsToCancel),
            "owners_refunded" => count($refundData),
            "refunds_attempted" => $refundData // <- this is now a proper object (map)
        ];

    } catch (Exception $e) {
        $conn->rollback();
        $response["message"] = "Error: " . $e->getMessage();
        error_log("Deactivation failed: " . $e->getMessage());
    }
} else {
    $response["message"] = "Invalid request";
}

header('Content-Type: application/json');
echo json_encode($response, JSON_PRETTY_PRINT);
$conn->close();
