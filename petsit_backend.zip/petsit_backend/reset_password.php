<?php
header("Content-Type: application/json");
require_once 'connection.php';

$data = json_decode(file_get_contents("php://input"), true);
$token = $data['token'] ?? '';
$newPassword = $data['newPassword'] ?? '';
$confirmPassword = $data['confirmPassword'] ?? '';

if (empty($token) || empty($newPassword) || empty($confirmPassword)) {
    echo json_encode(["success" => false, "message" => "All fields are required"]);
    exit();
}

if ($newPassword !== $confirmPassword) {
    echo json_encode(["success" => false, "message" => "Passwords don't match"]);
    exit();
}

// Verify token and update password
$stmt = $conn->prepare("SELECT email FROM petowner WHERE reset_token = ? AND reset_token_expires > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Invalid or expired reset token"]);
    exit();
}

$row = $result->fetch_assoc();
$email = $row['email'];

// Hash and update password
$hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
$updateStmt = $conn->prepare("UPDATE petowner SET password = ?, reset_code = NULL, reset_code_expires = NULL, reset_token = NULL, reset_token_expires = NULL WHERE email = ?");
$updateStmt->bind_param("ss", $hashedPassword, $email);

if ($updateStmt->execute()) {
    echo json_encode(["success" => true, "message" => "Password reset successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Failed to update password"]);
}

$updateStmt->close();
$conn->close();
?>