<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]));
}

// Get POST data
$data = json_decode(file_get_contents("php://input"), true);

// Extract data
$serviceid = $data['id'] ?? '';
$serviceName = $data['service_name'] ?? '';
$fromDate = $data['from_date'] ?? '';
$toDate = $data['to_date'] ?? '';
$fromTime = $data['from_time'] ?? '';
$toTime = $data['to_time'] ?? '';
$pets = implode(", ", $data['pets'] ?? []);
$petTypes = implode(", ", $data['pet_types'] ?? []);
$price = $data['price'] ?? '';
$totalPrice = $data['total_price'] ?? '';
$payMethod = $data['pay_method'] ?? '';
$petOwnerID = $data['petOwner_ID'] ?? 0;
$petSitterID = $data['petSitter_ID'] ?? 0;
$petIds = $data['pet_ids'] ?? []; // Get array of pet IDs

// Debug: Log received data
error_log("Received pet IDs: " . print_r($petIds, true));

// Validation
if ($petOwnerID <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid owner ID"]);
    exit;
}

if ($petSitterID <= 0) {
    echo json_encode(["status" => "error", "message" => "Invalid sitter ID"]);
    exit;
}

if (empty($serviceid)) {
    echo json_encode(["status" => "error", "message" => "Service ID is required"]);
    exit;
}

if (empty($petIds)) {
    echo json_encode(["status" => "error", "message" => "No pet IDs provided"]);
    exit;
}

$approval = 'pending';

// Start transaction
$conn->begin_transaction();

try {
    // Prepare the statement
    $stmt = $conn->prepare("INSERT INTO booking (
        service_id, 
        service_name, 
        FromDate, 
        ToDate, 
        FromTime, 
        ToTime, 
        Pets, 
        PetTypes, 
        Price, 
        TotalPrice, 
        PayMethod, 
        petOwner_ID, 
        petSitter_ID, 
        pet_id,  
        approval
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    // Insert a record for each pet
    $successCount = 0;
    foreach ($petIds as $petId) {
        $stmt->bind_param("isssssssdssiiis", 
            $serviceid,
            $serviceName, 
            $fromDate, 
            $toDate, 
            $fromTime, 
            $toTime, 
            $pets, 
            $petTypes, 
            $price, 
            $totalPrice, 
            $payMethod, 
            $petOwnerID, 
            $petSitterID,
            $petId, 
            $approval
        );

        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
        $successCount++;
    }

    // Commit transaction
    $conn->commit();

    echo json_encode([
        "status" => "success", 
        "message" => "Saved $successCount booking(s) successfully",
        "booked_pets" => $petIds
    ]);

} catch (Exception $e) {
    // Rollback transaction on error
    $conn->rollback();
    echo json_encode([
        "status" => "error", 
        "message" => "Error saving bookings: " . $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>