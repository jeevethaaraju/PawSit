<?php
// update_complaint_status.php
header("Content-Type: application/json");
require_once 'connection.php';

$response = array("success" => false, "message" => "");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (isset($data['complaint_id']) && isset($data['status']) && isset($data['admin_id'])) {
        $complaint_id = (int)$data['complaint_id'];
        $status = $data['status'];
        $admin_id = (int)$data['admin_id'];
        
        try {
            // Update complaint status
            $stmt = $conn->prepare("UPDATE complaints SET status = ?, reviewed_by = ? WHERE complaint_id = ?");
            $stmt->bind_param("sii", $status, $admin_id, $complaint_id);
            
            if ($stmt->execute()) {
                $response["success"] = true;
                $response["message"] = "Status updated";
                
                // Get complaint details for notification
                $complaint_stmt = $conn->prepare("SELECT user_id, description FROM complaints WHERE complaint_id = ?");
                $complaint_stmt->bind_param("i", $complaint_id);
                $complaint_stmt->execute();
                $complaint_result = $complaint_stmt->get_result();
                
                if ($complaint_result->num_rows > 0) {
                    $complaint = $complaint_result->fetch_assoc();
                    $user_id = $complaint['user_id'];
                    $message = "Your complaint (ID: $complaint_id) status has been updated to: $status";
                    
                    // Send notification
                    $notification_data = [
                        'user_id' => $user_id,
                        'complaint_id' => $complaint_id,
                        'message' => $message
                    ];
                    
                    $ch = curl_init();
                    curl_setopt($ch, CURLOPT_URL, "http://yourdomain.com/send_notification.php");
                    curl_setopt($ch, CURLOPT_POST, true);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification_data));
                    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    $notification_response = curl_exec($ch);
                    curl_close($ch);
                    
                    $response["notification"] = json_decode($notification_response, true);
                }
            } else {
                $response["message"] = "Update failed: " . $stmt->error;
            }
        } catch (Exception $e) {
            $response["message"] = "Database error: " . $e->getMessage();
        }
    } else {
        $response["message"] = "Missing parameters";
    }
} else {
    $response["message"] = "Invalid method";
}

echo json_encode($response);
$conn->close();
?>