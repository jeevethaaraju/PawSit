<?php
header("Content-Type: application/json");
require_once 'connection.php';

$response = ["success" => false, "message" => ""];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    
    $user_id = $data['user_id'] ?? null;
    $title = $data['title'] ?? null;
    $message = $data['message'] ?? null;
    
    if (!$user_id || !$title || !$message) {
        $response["message"] = "Missing parameters";
        echo json_encode($response);
        exit;
    }

    try {
        // Get FCM token
        $stmt = $conn->prepare("SELECT fcm_token FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $fcm_token = $user['fcm_token'];
            
            if ($fcm_token) {
                $url = 'https://fcm.googleapis.com/fcm/send';
                $serverKey = 'YOUR_FCM_SERVER_KEY';
                
                $notification = [
                    'title' => $title,
                    'body' => $message,
                    'sound' => 'default'
                ];
                
                $fields = [
                    'to' => $fcm_token,
                    'notification' => $notification,
                    'data' => ['type' => 'complaint_reviewed']
                ];

                $headers = [
                    'Authorization: key=' . $serverKey,
                    'Content-Type: application/json'
                ];

                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                
                $result = curl_exec($ch);
                curl_close($ch);
                
                $response["success"] = true;
                $response["message"] = "Notification sent";
            }
        }
    } catch (Exception $e) {
        $response["message"] = "Error: " . $e->getMessage();
    }
}

echo json_encode($response);
$conn->close();
?>