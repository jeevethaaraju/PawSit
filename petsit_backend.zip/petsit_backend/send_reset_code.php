<?php
header("Content-Type: application/json");
require_once 'connection.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kuala_Lumpur');
$conn->query("SET time_zone = '+08:00'");

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';

if (empty($email)) {
    echo json_encode(["success" => false, "message" => "Email is required"]);
    exit();
}

// Check if email exists
$stmt = $conn->prepare("SELECT reset_code, reset_code_expires, reset_token, reset_token_expires FROM petowner WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Email not found"]);
    exit();
}

$row = $result->fetch_assoc();
$current_time = date("Y-m-d H:i:s");

// Check if valid reset code already exists
if (!empty($row['reset_code']) && $row['reset_code_expires'] > $current_time && 
    !empty($row['reset_token']) && $row['reset_token_expires'] > $current_time) {
    echo json_encode(["success" => true, "message" => "Reset code already sent to your email. Please check your inbox."]);
    exit();
}

// Generate new codes and tokens
$code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$token = bin2hex(random_bytes(32)); // Secure random token
$expires = date("Y-m-d H:i:s", strtotime("+15 minutes"));

// Update both code and token in database
$updateStmt = $conn->prepare("UPDATE petowner SET 
    reset_code = ?, 
    reset_code_expires = ?,
    reset_token = ?,
    reset_token_expires = ?
    WHERE Email = ?");
$updateStmt->bind_param("sssss", $code, $expires, $token, $expires, $email);
$updateStmt->execute();
$updateStmt->close();

// Send email with just the code (token is for API use only)
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'rajusubramaniam10@gmail.com';
    $mail->Password = 'fqib lwyh bdnt hazw';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('rajusubramaniam10@gmail.com', 'PetSit');
    $mail->addAddress($email);

    $mail->Subject = "Password Reset Code";
    $mail->Body = "Your password reset code is: $code\n\nThis code expires in 15 minutes.";

    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Reset code sent to your email",
        // Debug only - remove in production:
        "debug_token" => $token
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Failed to send reset code. Please try again later."
    ]);
}

$conn->close();
?>