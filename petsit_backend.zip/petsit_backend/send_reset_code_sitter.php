<?php
header("Content-Type: application/json");
require_once 'connection.php';
require 'PHPMailer/PHPMailer.php';
require 'PHPMailer/SMTP.php';
require 'PHPMailer/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

date_default_timezone_set('Asia/Kuala_Lumpur');
$conn->query("SET time_zone = '+08:00'");

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';

if (empty($email)) {
    echo json_encode(["success" => false, "message" => "Email address is required"]);
    exit();
}

// Check if email exists
$stmt = $conn->prepare("SELECT reset_code, reset_code_expires FROM petsitter WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Email not found - respond with success=false to prevent enumeration attacks
    echo json_encode([
        "success" => false,
        "message" => "Email not found"
    ]);
    exit();
}

$row = $result->fetch_assoc();
$current_time = date("Y-m-d H:i:s");

// Check if valid reset code already exists
if (!empty($row['reset_code']) && $row['reset_code_expires'] > $current_time) {
    echo json_encode([
        "success" => true,
        "message" => "A reset code was recently sent. Please check your email.",
        "code_exists" => true
    ]);
    exit();
}

// Generate new 6-digit reset code
$code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
$expires = date("Y-m-d H:i:s", strtotime("+15 minutes"));

// Update reset code and expiration
$updateStmt = $conn->prepare("UPDATE petsitter SET reset_code = ?, reset_code_expires = ? WHERE Email = ?");
$updateStmt->bind_param("sss", $code, $expires, $email);
$updateStmt->execute();
$updateStmt->close();

// Send email
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'rajusubramaniam10@gmail.com';
    $mail->Password = 'fqib lwyh bdnt hazw';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('rajusubramaniam10@gmail.com', 'PetSit');
    $mail->addAddress($email);

    $mail->Subject = "Password Reset Code";
    $mail->Body = "Your password reset code is: $code\n\nThis code expires in 15 minutes.";

    $mail->send();

    echo json_encode([
        "success" => true,
        "message" => "Password reset code sent successfully. Please check your email."
    ]);
} catch (Exception $e) {
    // Rollback the code if email fails to send
    $conn->query("UPDATE petsitter SET reset_code = NULL, reset_code_expires = NULL WHERE Email = '$email'");
    
    echo json_encode([
        "success" => false,
        "message" => "Failed to send reset code. Please try again later."
    ]);
}

$conn->close();
?>