<?php
session_start();
header("Content-Type: application/json");

// Debug session
error_log("Session data: " . print_r($_SESSION, true));

if (!isset($_SESSION['petSitter']) || !isset($_SESSION['petSitter']['petSitterId'])) {
    error_log("Session check failed");
    echo json_encode(['status' => 'error', 'message' => 'Not logged in']);
    exit;
}

$host = "localhost";
$db_name = "petsit";
$username = "root";
$password = "";

$conn = new mysqli($host, $username, $password, $db_name);

if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
    die();
}

// Handle multiple file uploads
$uploadedImages = [];
if (isset($_FILES['picture'])) {
    $uploadDir = 'uploads/';
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }
    
    // Process each uploaded file
    foreach ($_FILES['picture']['tmp_name'] as $key => $tmpName) {
        if ($_FILES['picture']['error'][$key] !== UPLOAD_ERR_OK) {
            continue; // Skip if there was an upload error
        }
        
        $originalName = basename($_FILES['picture']['name'][$key]);
        $extension = pathinfo($originalName, PATHINFO_EXTENSION);
        $fileName = uniqid() . '.' . $extension;
        $targetPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($tmpName, $targetPath)) {
            $uploadedImages[] = $targetPath; // Store the full path
        }
    }
}

// Get other data from POST request
$data = json_decode($_POST['data'] ?? file_get_contents("php://input"), true);
if (is_string($data)) {
    $data = json_decode($data, true);
}

// Prepare the data strings
$accept_pet = [];
if (isset($data['cat_checked']) && $data['cat_checked']) $accept_pet[] = "Cat";
if (isset($data['dog_checked']) && $data['dog_checked']) $accept_pet[] = "Dog";
$accept_pet_str = implode(", ", $accept_pet);

$accept_petsize = [];
if (isset($data['size_small_checked']) && $data['size_small_checked']) $accept_petsize[] = "Small (0-15 lbs)";
if (isset($data['size_medium_checked']) && $data['size_medium_checked']) $accept_petsize[] = "Medium (16-40 lbs)";
if (isset($data['size_large_checked']) && $data['size_large_checked']) $accept_petsize[] = "Large (41-100 lbs)";
if (isset($data['size_giant_checked']) && $data['size_giant_checked']) $accept_petsize[] = "Giant (100+ lbs)";
$accept_petsize_str = implode(", ", $accept_petsize);

$services = [];
if (isset($data['bath_checked']) && $data['bath_checked']) $services[] = "Bathing";
if (isset($data['walking_checked']) && $data['walking_checked']) $services[] = "Walking";
if (isset($data['feeding_checked']) && $data['feeding_checked']) $services[] = "Feeding";
if (isset($data['playing_checked']) && $data['playing_checked']) $services[] = "Playing";
$services_str = implode(", ", $services);

// Initialize image paths (up to 3 images)
$picture1 = null;
$picture2 = null;
$picture3 = null;

// Assign uploaded images to the appropriate columns
if (count($uploadedImages) > 0) $picture1 = $uploadedImages[0];
if (count($uploadedImages) > 1) $picture2 = $uploadedImages[1];
if (count($uploadedImages) > 2) $picture3 = $uploadedImages[2];

try {
    // Modified SQL to include multiple picture columns
    $stmt = $conn->prepare("INSERT INTO services (
        service_name, 
        summ, 
        numofpets, 
        accept_pet, 
        accept_petsize, 
        unsupervised, 
        potty, 
        walks, 
        home, 
        transport, 
        price, 
        service, 
        petsitter_id,
        picture1,
        picture2,
        picture3
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    // Bind parameters
    $stmt->bind_param("ssssssssssssssss",
        $data['service_name'],
        $data['summary'],
        $data['num_pets'],
        $accept_pet_str,
        $accept_petsize_str,
        $data['where_spinner'],
        $data['potty_spinner'],
        $data['walks_spinner'],
        $data['home_spinner'],
        $data['transport_spinner'],
        $data['price'],
        $services_str,
        $_SESSION['petSitter']['petSitterId'],
        $picture1,
        $picture2,
        $picture3
    );

    $stmt->execute();

    $response = [
        "status" => "success",
        "message" => "Service added successfully",
        "service_id" => $stmt->insert_id,
        "images" => $uploadedImages
    ];
    echo json_encode($response);

} catch(Exception $e) {
    // Delete any uploaded files if there was an error
    foreach ($uploadedImages as $imagePath) {
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }
    }
    
    $response = [
        "status" => "error",
        "message" => "Error: " . $e->getMessage(),
        "debug" => $e->getTraceAsString()
    ];
    echo json_encode($response);
}

$stmt->close();
$conn->close();
?>