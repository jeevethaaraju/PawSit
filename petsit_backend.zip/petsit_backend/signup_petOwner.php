<?php
$host = "localhost"; // usually localhost
$user = "root";
$pass = "";
$db = "petsit"; // your database name

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST values
$firstName = $_POST['firstName'] ?? '';
$lastName = $_POST['lastName'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$repass = $_POST['repass'] ?? '';
$gender = $_POST['gender'] ?? '';
$dateOfBirth = $_POST['dateOfBirth'] ?? '';

// Default values
$role = "Owner";
$wallet_balance = 0.0;

// Simple insert query
$sql = "INSERT INTO petOwner (firstName, lastName, email, password, repass, gender, dateOfBirth, role, wallet_balance)
        VALUES ('$firstName', '$lastName', '$email', '$password', '$repass', '$gender', '$dateOfBirth', '$role', '$wallet_balance')";

if ($conn->query($sql) === TRUE) {
    echo "success";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>
