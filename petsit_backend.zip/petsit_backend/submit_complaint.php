<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    echo json_encode(["status" => "error", "message" => "Connection failed: " . $conn->connect_error]);
    exit;
}

// Get POST data
$bookingId    = isset($_POST['booking_id']) ? $_POST['booking_id'] : '';
$petOwnerId   = isset($_POST['petOwner_ID']) ? $_POST['petOwner_ID'] : '';
$description  = isset($_POST['description']) ? $_POST['description'] : '';
$proofImage   = isset($_POST['proof_image']) ? $_POST['proof_image'] : '';

// Validate input
if (empty($bookingId) || empty($petOwnerId) || empty($description) || empty($proofImage)) {
    echo json_encode(["status" => "error", "message" => "Missing required fields"]);
    exit;
}

// Check if a complaint already exists for this booking
$check = $conn->prepare("SELECT complaint_id FROM complaints WHERE booking_id = ?");
$check->bind_param("i", $bookingId);
$check->execute();
$checkResult = $check->get_result();

if ($checkResult->num_rows > 0) {
    echo json_encode(["status" => "error", "message" => "Complaint already exists for this booking"]);
    $check->close();
    $conn->close();
    exit;
}
$check->close();

// Retrieve petSitter_ID, FromDate, and ToDate from booking
$stmt = $conn->prepare("SELECT petSitter_ID, FromDate, ToDate FROM booking WHERE booking_id = ?");
$stmt->bind_param("i", $bookingId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => "error", "message" => "Invalid booking ID"]);
    $stmt->close();
    $conn->close();
    exit;
}

$row = $result->fetch_assoc();
$petSitterId = $row['petSitter_ID'];
$fromDateRaw = $row['FromDate'];
$toDateRaw = $row['ToDate'];
$stmt->close();

// Check if complaint is within 3 days after ToDate
$currentDate = new DateTime();
$toDate = new DateTime($toDateRaw);
$interval = $toDate->diff($currentDate)->format("%r%a"); // %r gives sign, %a gives days

if ((int)$interval > 3) {
    echo json_encode([
        "status" => "error",
        "message" => "This booking is more than 3 days old. You can no longer submit a complaint."
    ]);
    exit;
}

// Save image to server
$imageName = uniqid() . '.jpg';
$imagePath = 'uploads/' . $imageName;
$decodedImage = base64_decode($proofImage);

// Make sure uploads directory exists
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

// Save the image
if (!file_put_contents($imagePath, $decodedImage)) {
    echo json_encode(["status" => "error", "message" => "Failed to save image"]);
    exit;
}

// Insert complaint including FromDate and image path
$insert = $conn->prepare("INSERT INTO complaints 
    (booking_id, petOwner_ID, petSitter_ID, description, status, created_at, FromDate, proof_image) 
    VALUES (?, ?, ?, ?, 'pending', CURRENT_TIMESTAMP, ?, ?)");
$insert->bind_param("iiisss", $bookingId, $petOwnerId, $petSitterId, $description, $fromDateRaw, $imagePath);

if ($insert->execute()) {
    echo json_encode([
        "status" => "success",
        "message" => "Complaint submitted successfully",
        "FromDate" => date("d M Y", strtotime($fromDateRaw))
    ]);
} else {
    // Delete the image if database insert failed
    unlink($imagePath);
    echo json_encode(["status" => "error", "message" => "Failed to submit complaint"]);
}

$insert->close();
$conn->close();
?>
