<?php
$conn = new mysqli("localhost", "root", "", "medicine_reco");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Database connected successfully!";
?>
