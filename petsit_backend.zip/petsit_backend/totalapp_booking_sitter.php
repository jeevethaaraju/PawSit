<?php
header("Content-Type: application/json");
include 'connection.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_GET['sitter_id']) || empty($_GET['sitter_id'])) {
    http_response_code(400);
    echo json_encode([
        "status" => "error",
        "message" => "Sitter ID not provided or empty"
    ]);
    exit;
}

$sitterId = intval($_GET['sitter_id']);

// Check if sitter exists
$checkQuery = "SELECT id FROM petsitter WHERE id = $sitterId";
$checkResult = $conn->query($checkQuery);

if (!$checkResult || $checkResult->num_rows === 0) {
    http_response_code(404);
    echo json_encode([
        "status" => "error",
        "message" => "Pet sitter not found"
    ]);
    exit;
}

// Get completed bookings
$bookingQuery = "SELECT COUNT(*) AS approved_bookings FROM booking WHERE petSitter_ID = $sitterId AND approval = 'approved'";
$bookingResult = $conn->query($bookingQuery);

if ($bookingResult) {
    $row = $bookingResult->fetch_assoc();
    echo json_encode([
        "status" => "success",
        "approved_bookings" => intval($row['approved_bookings'])
    ]);
} else {
    http_response_code(500);
    echo json_encode([
        "status" => "error",
        "message" => "Query failed: " . $conn->error
    ]);
}

$conn->close();
?>
