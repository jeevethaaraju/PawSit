<?php
header("Content-Type: text/plain"); // Changed to plain text for simple responses

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$email = isset($_POST['email']) ? $_POST['email'] : '';
$currentPassword = isset($_POST['current_password']) ? $_POST['current_password'] : '';
$newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';

// Validate inputs
if (empty($email) || empty($currentPassword) || empty($newPassword)) {
    echo "All fields are required";
    exit;
}

// Check if admin exists
$stmt = $conn->prepare("SELECT id, Password FROM petadmin WHERE Email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "Admin account not found";
    exit;
}

$admin = $result->fetch_assoc();

// Verify password (works for both hashed and plain text)
if (password_verify($currentPassword, $admin['Password']) || $currentPassword === $admin['Password']) {
    // Hash the new password
    $hashedNewPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    
    // Update password
    $updateStmt = $conn->prepare("UPDATE petadmin SET Password = ? WHERE Email = ?");
    $updateStmt->bind_param("ss", $hashedNewPassword, $email);

    if ($updateStmt->execute()) {
        echo "Password updated successfully!";
    } else {
        echo "Failed to update password. Please try again.";
    }
    $updateStmt->close();
} else {
    echo "Current password is incorrect";
}

$stmt->close();
$conn->close();
?>