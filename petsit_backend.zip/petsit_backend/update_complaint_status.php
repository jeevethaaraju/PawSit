<?php
header("Content-Type: application/json");
require_once 'connection.php';

ini_set('display_errors', 1);
error_reporting(E_ALL);

$response = array("success" => false, "message" => "");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['complaint_id']) && isset($_POST['status'])) {
        $complaint_id = $_POST['complaint_id'];
        $status = $_POST['status'];

        $valid_statuses = array("pending", "reviewed", "resolved", "rejected");
        if (!in_array(strtolower($status), $valid_statuses)) {
            $response["message"] = "Invalid status value";
            echo json_encode($response);
            exit;
        }

        try {
            $stmt = $conn->prepare("SELECT petSitter_ID FROM complaints WHERE complaint_id = ?");
            $stmt->bind_param("i", $complaint_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $complaint = $result->fetch_assoc();
            $stmt->close();

            if (!$complaint) {
                $response["message"] = "Complaint not found";
                echo json_encode($response);
                exit;
            }

            $pet_sitter_id = $complaint['petSitter_ID'];

            // Update status
            $stmt = $conn->prepare("UPDATE complaints SET status = ? WHERE complaint_id = ?");
            $stmt->bind_param("si", $status, $complaint_id);

            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    $response["success"] = true;
                    $response["message"] = "Status updated successfully";

                    if (strtolower($status) == "reviewed") {
                        $message = "Your complaint #$complaint_id has been reviewed by admin";

                        // Insert notification into database
                        $stmtNotif = $conn->prepare("INSERT INTO notifications (user_id, complaint_id, message, is_read, created_at) VALUES (?, ?, ?, 0, NOW())");
                        $stmtNotif->bind_param("iis", $pet_sitter_id, $complaint_id, $message);

                        if ($stmtNotif->execute()) {
                            $response["notification"] = "Notification stored in database";
                        } else {
                            $response["notification"] = "Failed to store notification: " . $stmtNotif->error;
                        }

                        $stmtNotif->close();
                    }
                } else {
                    $response["message"] = "No changes made or complaint not found";
                }
            } else {
                $response["message"] = "Error updating status: " . $stmt->error;
            }

            $stmt->close();
        } catch (Exception $e) {
            $response["message"] = "Database error: " . $e->getMessage();
        }
    } else {
        $response["message"] = "Missing required parameters";
    }
} else {
    $response["message"] = "Invalid request method";
}

echo json_encode($response);
$conn->close();
?>
