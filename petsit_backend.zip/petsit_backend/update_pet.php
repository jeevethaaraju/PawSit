<?php
header('Content-Type: application/json');
require_once 'connection.php';

$response = array('success' => false);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    // Initialize variables
    $id = $petName = $petType = $petBreed = $petSize = $petGender = $petBirthDate = $petImage = '';
    
    // Check if request is JSON (with image) or form-data
    if (json_last_error() === JSON_ERROR_NONE) {
        // Handle JSON request (with base64 image)
        $id = $input['pet_id'];
        $petName = $input['pet_name'];
        $petType = $input['pet_type'];
        $petBreed = $input['pet_breed'];
        $petSize = $input['pet_size'];
        $petGender = $input['pet_gender'];
        $petBirthDate = $input['pet_birth'];
        $petImage = $input['current_image']; // Existing image filename
        
        if (!empty($input['pet_image'])) {
            $imageData = base64_decode($input['pet_image']);
            $fileName = uniqid() . '.jpg';
            $filePath = "uploads/" . $fileName;
            
            if (file_put_contents($filePath, $imageData)) {
                // Delete old image if it exists and is different from new one
                if (!empty($petImage) && file_exists("uploads/" . $petImage) && $petImage !== $fileName) {
                    unlink("uploads/" . $petImage);
                }
                $petImage = $fileName; // Update with new filename
            }
        }
    } else {
        // Handle regular form-data
        $id = $_POST['pet_id'];
        $petName = $_POST['pet_name'];
        $petType = $_POST['pet_type'];
        $petBreed = $_POST['pet_breed'];
        $petSize = $_POST['pet_size'];
        $petGender = $_POST['pet_gender'];
        $petBirthDate = $_POST['pet_birth'];
        $petImage = $_POST['current_image']; // Existing image filename
        
        if (isset($_FILES['pet_image']) && $_FILES['pet_image']['error'] == UPLOAD_ERR_OK) {
            $targetDir = "uploads/";
            $fileName = uniqid() . '_' . basename($_FILES["pet_image"]["name"]);
            $targetFile = $targetDir . $fileName;
            
            if (move_uploaded_file($_FILES["pet_image"]["tmp_name"], $targetFile)) {
                // Delete old image if it exists and is different from new one
                if (!empty($petImage) && file_exists($targetDir . $petImage) && $petImage !== $fileName) {
                    unlink($targetDir . $petImage);
                }
                $petImage = $fileName; // Update with new filename
            }
        }
    }

    // Update database
    $stmt = $conn->prepare("UPDATE pet SET 
                          petName = ?, 
                          petType = ?, 
                          petBreed = ?, 
                          petSize = ?, 
                          petGender = ?, 
                          petBirthDate = ?, 
                          petImage = ? 
                          WHERE id = ?");
    $stmt->bind_param("sssssssi", $petName, $petType, $petBreed, 
                     $petSize, $petGender, $petBirthDate, $petImage, $id);

    if ($stmt->execute()) {
        $response['success'] = true;
        $response['message'] = "Pet updated successfully";
        $response['new_image'] = $petImage;
    } else {
        $response['error'] = "Error updating pet: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
} else {
    $response['error'] = "Invalid request method";
}

echo json_encode($response);
?>