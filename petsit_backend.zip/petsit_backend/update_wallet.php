<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(["status" => "error", "message" => "Connection failed"]));
}

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Debug logging
file_put_contents('wallet_debug.log', print_r($data, true), FILE_APPEND);

if (!isset($data['owner_id']) || !isset($data['amount'])) {
    echo json_encode(["status" => "error", "message" => "Missing parameters"]);
    exit;
}

$ownerId = (int)$data['owner_id'];
$amount = $data['amount'];

// Convert amount to float regardless of input type
if (is_string($amount)) {
    $amount = (float) preg_replace('/[^0-9.]/', '', $amount);
}

$conn->begin_transaction();

try {
    // 1. Verify owner exists with row lock
    $stmt = $conn->prepare("SELECT WalletBalance FROM petowner WHERE id = ? FOR UPDATE");
    $stmt->bind_param("i", $ownerId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        throw new Exception("Owner not found");
    }

    $row = $result->fetch_assoc();
    $currentBalance = (float)$row['WalletBalance'];
    $newBalance = $currentBalance + $amount;

    // 2. Update balance
    $update = $conn->prepare("UPDATE petowner SET WalletBalance = ? WHERE id = ?");
    $update->bind_param("di", $newBalance, $ownerId);
    
    if (!$update->execute()) {
        throw new Exception("Update failed");
    }

    $conn->commit();

    echo json_encode([
        "status" => "success",
        "new_balance" => $newBalance,
        "debug" => [
            "received_amount" => $data['amount'],
            "processed_amount" => $amount,
            "previous_balance" => $currentBalance
        ]
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
} finally {
    $conn->close();
}
?>