<?php
include('config.php');
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get input data
    $data = json_decode(file_get_contents("php://input"), true);

    // Debug logging
    error_log("Received data: " . print_r($data, true));

    // Required fields
    $firstName = $data['FirstName'];
    $lastName = $data['LastName'];
    $email = $data['Email'];
    $gender = $data['Gender'];
    $birthDate = $data['Birth_Date'];
    $phoneNumber = $data['Phone_Number'];
    
    // Phone number validation
    $phoneNumber = preg_replace('/[^0-9]/', '', $phoneNumber); // Remove all non-numeric characters
    if (strlen($phoneNumber) < 10 || strlen($phoneNumber) > 12) {
        throw new Exception("Phone number must be between 10-12 digits");
    }

    // Optional location fields
    $location = isset($data['Location']) ? $data['Location'] : null;
    $lat = isset($data['lat']) ? $data['lat'] : null;
    $lng = isset($data['lng']) ? $data['lng'] : null;

    // Initialize image variables
    $imageName = null;
    $savedImagePath = null;

    // Handle image upload if provided
    if (!empty($data['ProfileImage']) && !empty($data['OriginalFilename'])) {
        $imageData = $data['ProfileImage'];
        $originalFilename = $data['OriginalFilename'];

        $imageName = preg_replace('/[^a-zA-Z0-9\-_\.]/', '', $originalFilename);
        
        $uploadDir = 'uploads/';
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $uploadDir . $imageName;
        $webPath = BASE_URL . $uploadDir . $imageName;

        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (strpos($imageData, 'data:image') === 0) {
            list($type, $imageData) = explode(';', $imageData);
            list(, $imageData) = explode(',', $imageData);
            $decodedImage = base64_decode($imageData);

            if (file_put_contents($fullPath, $decodedImage)) {
                $savedImagePath = $uploadDir . $imageName;
                error_log("Image saved to: " . $savedImagePath);
            } else {
                throw new Exception("Failed to save image file. Check directory permissions.");
            }
        }
    }

    // Update database with location fields
    $stmt = $conn->prepare("UPDATE petowner SET 
                          FirstName = :firstName,
                          LastName = :lastName,
                          Gender = :gender,
                          Birth_Date = :birthDate,
                          Phone_Number = :phoneNumber,
                          Location = COALESCE(:location, Location),
                          lat = COALESCE(:lat, lat),
                          lng = COALESCE(:lng, lng),
                          ProfileImage = COALESCE(:profileImage, ProfileImage)
                          WHERE Email = :email");
    
    $stmt->bindParam(':firstName', $firstName);
    $stmt->bindParam(':lastName', $lastName);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':birthDate', $birthDate);
    $stmt->bindParam(':phoneNumber', $phoneNumber);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':lat', $lat);
    $stmt->bindParam(':lng', $lng);
    $stmt->bindParam(':profileImage', $savedImagePath);
    $stmt->bindParam(':email', $email);
    
    if ($stmt->execute()) {
        $response = [
            'status' => 'success',
            'message' => 'Profile updated successfully',
            'data' => [
                'FirstName' => $firstName,
                'LastName' => $lastName,
                'Email' => $email,
                'Location' => $location,
                'lat' => $lat,
                'lng' => $lng,
                'Phone_Number' => $phoneNumber
            ]
        ];
        
        if ($savedImagePath) {
            $response['imageUrl'] = BASE_URL . $savedImagePath;
            $response['data']['ProfileImage'] = $savedImagePath;
        }
        
        echo json_encode($response);
    } else {
        $errorInfo = $stmt->errorInfo();
        throw new Exception("Database update failed: " . $errorInfo[2]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>