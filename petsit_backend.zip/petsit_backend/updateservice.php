<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', 'php_errors.log');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

$response = [
    "status" => "error",
    "message" => "Unknown error occurred",
    "debug" => []
];

try {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        throw new Exception("Database connection failed: " . $conn->connect_error);
    }

    $input = file_get_contents("php://input");
    $data = json_decode($input, true);

    if ($data === null) {
        throw new Exception("Invalid JSON data received");
    }

    error_log("Received data: " . print_r($data, true));
    $response['debug']['received_data'] = $data;

    if (!isset($data['petsitter_id'])) {
        throw new Exception("Missing required field: petsitter_id");
    }

    $petsitterId = (int)$data['petsitter_id'];

    // Check for existing service
    $checkQuery = "SELECT picture1, picture2, picture3 FROM services WHERE petsitter_id = ? LIMIT 1";
    $checkStmt = $conn->prepare($checkQuery);
    if (!$checkStmt) throw new Exception("Prepare failed: " . $conn->error);

    $checkStmt->bind_param("i", $petsitterId);
    $checkStmt->execute();
    $result = $checkStmt->get_result();
    $existingService = $result->fetch_assoc();
    $checkStmt->close();

    if (!$existingService) {
        throw new Exception("No service found for the given petsitter_id");
    }

    $fieldMappings = [
        'service_name' => 'service_name',
        'summ' => 'summ',
        'numofpets' => 'numofpets',
        'accept_pet' => 'accept_pet',
        'accept_petsize' => 'accept_petsize',
        'accept_petSize' => 'accept_petsize',
        'unsupervised' => 'unsupervised',
        'potty' => 'potty',
        'walks' => 'walks',
        'home' => 'home',
        'transport' => 'transport',
        'price' => 'price',
        'service' => 'service'
    ];

    $updateFields = [];
    $types = "";
    $params = [];

    foreach ($fieldMappings as $inputField => $dbField) {
        if (isset($data[$inputField])) {
            if (!array_key_exists($dbField, $existingService) || $existingService[$dbField] != $data[$inputField]) {
                $updateFields[] = "$dbField = ?";
                $params[] = $data[$inputField];
                $types .= "s";
            }
        }
    }

    $uploadDir = 'uploads/';
    $imageFields = ['picture1', 'picture2', 'picture3'];

    // Handle image deletions first
    if (isset($data['delete_images']) && is_array($data['delete_images'])) {
        foreach ($data['delete_images'] as $imageIndex) {
            if (isset($imageFields[$imageIndex])) {
                $fieldName = $imageFields[$imageIndex];
                $currentImage = $existingService[$fieldName] ?? null;
                
                if ($currentImage) {
                    $imageFile = basename($currentImage);
                    if (file_exists($uploadDir . $imageFile)) {
                        unlink($uploadDir . $imageFile);
                    }
                    $updateFields[] = "$fieldName = NULL";
                }
            }
        }
    }

    // Handle new image uploads
    if (isset($data['images']) && is_array($data['images'])) {
        foreach ($data['images'] as $imageData) {
            if (!isset($imageData['image_base64']) || empty($imageData['image_base64'])) {
                continue;
            }

            // Validate position
            if (!isset($imageData['position']) || !is_numeric($imageData['position'])) {
                throw new Exception("Image position must be specified (0, 1, or 2)");
            }

            $position = (int)$imageData['position'];
            if ($position < 0 || $position > 2) {
                throw new Exception("Invalid image position. Must be 0, 1, or 2");
            }

            $imageField = $imageFields[$position];

            // Ensure upload directory exists
            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0777, true)) {
                    throw new Exception("Failed to create upload directory");
                }
            }

            // Generate filename
            $originalName = isset($imageData['original_filename']) ? 
                preg_replace("/[^a-zA-Z0-9._-]/", "_", basename($imageData['original_filename'])) : 
                '';
            $extension = pathinfo($originalName, PATHINFO_EXTENSION) ?: 'jpg';
            $imageName = uniqid('img_') . ($originalName ? "_$originalName" : ".$extension");
            $imagePath = $uploadDir . $imageName;

            // Decode and save image
            $decodedImage = base64_decode($imageData['image_base64']);
            if ($decodedImage === false) {
                throw new Exception("Invalid base64 image data");
            }

            if (file_put_contents($imagePath, $decodedImage) === false) {
                throw new Exception("Failed to save image to $imagePath");
            }

            // Verify image
            if (!file_exists($imagePath) || filesize($imagePath) === 0) {
                unlink($imagePath);
                throw new Exception("Failed to create valid image file");
            }

            // Delete old image if exists
            $currentImage = $existingService[$imageField] ?? null;
            if ($currentImage) {
                $oldImage = basename($currentImage);
                if (file_exists($uploadDir . $oldImage)) {
                    unlink($uploadDir . $oldImage);
                }
            }

            // Add to update
            $updateFields[] = "$imageField = ?";
            $params[] = $imagePath;
            $types .= "s";

            $response['debug']['uploaded_images'][$position] = [
                'field' => $imageField,
                'path' => $imagePath,
                'position' => $position
            ];
        }
    }

    if (empty($updateFields)) {
        $response['status'] = "success";
        $response['message'] = "No changes detected";
        echo json_encode($response);
        exit;
    }

    $params[] = $petsitterId;
    $types .= "i";

    $query = "UPDATE services SET " . implode(", ", $updateFields) . " WHERE petsitter_id = ?";
    $stmt = $conn->prepare($query);
    if (!$stmt) throw new Exception("Prepare failed: " . $conn->error);

    if (!$stmt->bind_param($types, ...$params)) {
        throw new Exception("Bind failed: " . $stmt->error);
    }

    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    $response['status'] = "success";
    $response['message'] = "Service updated successfully";
    $response['affected_rows'] = $stmt->affected_rows;
    $response['service_id'] = $petsitterId;

    $stmt->close();
    $conn->close();

} catch (Exception $e) {
    $response['message'] = $e->getMessage();
    error_log("Error: " . $e->getMessage());
    $response['debug']['trace'] = $e->getTraceAsString();
}

echo json_encode($response);
?>