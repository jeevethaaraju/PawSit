<?php
include('config.php');
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$host = "localhost";
$dbname = "petsit";
$username = "root";
$password = "";

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $data = json_decode(file_get_contents("php://input"), true);

    // Basic profile fields
    $firstName = $data['FirstName'];
    $lastName = $data['LastName'];
    $email = $data['Email'];
    $gender = $data['Gender'];
    $birthDate = $data['Birth_Date'];
    $phoneNumber = $data['Phone_Number'];

    // Optional location fields
    $location = $data['Location'] ?? null;
    $lat = $data['lat'] ?? null;
    $lng = $data['lng'] ?? null;

    // Image upload
    $imageName = null;
    $savedImagePath = null;

    if (!empty($data['ProfileImage']) && !empty($data['OriginalFilename'])) {
        $imageData = $data['ProfileImage'];
        $originalFilename = $data['OriginalFilename'];
        $imageName = preg_replace('/[^a-zA-Z0-9\-_\.]/', '', $originalFilename);
        $uploadDir = 'uploads/';
        $fullPath = $_SERVER['DOCUMENT_ROOT'] . '/' . $uploadDir . $imageName;
        $webPath = BASE_URL . $uploadDir . $imageName;

        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        if (strpos($imageData, 'data:image') === 0) {
            list($type, $imageData) = explode(';', $imageData);
            list(, $imageData) = explode(',', $imageData);
            $decodedImage = base64_decode($imageData);

            if (file_put_contents($fullPath, $decodedImage)) {
                $savedImagePath = $uploadDir . $imageName;
            } else {
                throw new Exception("Failed to save image file. Check directory permissions.");
            }
        }
    }

    // Update database with all fields including lat/lng
    $stmt = $conn->prepare("UPDATE petsitter SET 
                            FirstName = :firstName,
                            LastName = :lastName,
                            Gender = :gender,
                            Birth_Date = :birthDate,
                            Phone_Number = :phoneNumber,
                            Location = COALESCE(:location, Location),
                            lat = COALESCE(:lat, lat),
                            lng = COALESCE(:lng, lng),
                            ProfileImage = COALESCE(:profileImage, ProfileImage)
                            WHERE Email = :email");

    $stmt->bindParam(':firstName', $firstName);
    $stmt->bindParam(':lastName', $lastName);
    $stmt->bindParam(':gender', $gender);
    $stmt->bindParam(':birthDate', $birthDate);
    $stmt->bindParam(':phoneNumber', $phoneNumber);
    $stmt->bindParam(':location', $location);
    $stmt->bindParam(':lat', $lat);
    $stmt->bindParam(':lng', $lng);
    $stmt->bindParam(':profileImage', $savedImagePath);
    $stmt->bindParam(':email', $email);

    if ($stmt->execute()) {
        $response = [
            'status' => 'success',
            'message' => 'Profile updated successfully',
            'location' => $location,
            'lat' => $lat,
            'lng' => $lng
        ];

        if ($savedImagePath) {
            $response['imageUrl'] = BASE_URL . $savedImagePath;
        }

        echo json_encode($response);
    } else {
        throw new Exception("Database update failed");
    }

} catch (PDOException $e) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?>