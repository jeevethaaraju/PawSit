<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

$response = ["success" => false, "message" => "Initial error"];

try {
    if ($_SERVER['REQUEST_METHOD'] != 'POST') {
        throw new Exception("Invalid request method");
    }

    if (!isset($_FILES['profile_image'])) {
        throw new Exception("No file uploaded");
    }

    $uploadDir = "uploads/";
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $fileName = uniqid() . '_' . basename($_FILES['profile_image']['name']);
    $targetPath = $uploadDir . $fileName;
    $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));

    // Check if image file is a actual image
    $check = getimagesize($_FILES['profile_image']['tmp_name']);
    if ($check === false) {
        throw new Exception("File is not an image");
    }

    // Check file size (5MB max)
    if ($_FILES['profile_image']['size'] > 5000000) {
        throw new Exception("File is too large (max 5MB)");
    }

    // Allow certain file formats
    $allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    if (!in_array($imageFileType, $allowedTypes)) {
        throw new Exception("Only JPG, JPEG, PNG & GIF files are allowed");
    }

    // Upload file
    if (move_uploaded_file($_FILES['profile_image']['tmp_name'], $targetPath)) {
        $response = [
            "success" => true,
            "message" => "File uploaded successfully",
            "image_path" => $targetPath
        ];
    } else {
        throw new Exception("Error uploading file");
    }
} catch (Exception $e) {
    $response["message"] = $e->getMessage();
}

echo json_encode($response);
?>