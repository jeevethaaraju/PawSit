<?php
header("Content-Type: application/json");
require_once 'connection.php';

$data = json_decode(file_get_contents("php://input"), true);
$email = $data['email'] ?? '';
$code = $data['code'] ?? '';

if (empty($email) || empty($code)) {
    echo json_encode(["success" => false, "message" => "Email and code are required"]);
    exit();
}

// Verify code and get token
$stmt = $conn->prepare("SELECT reset_token FROM petowner WHERE email = ? AND reset_code = ? AND reset_code_expires > NOW()");
$stmt->bind_param("ss", $email, $code);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["success" => false, "message" => "Invalid or expired reset code"]);
    exit();
}

$row = $result->fetch_assoc();
$token = $row['reset_token'];

echo json_encode([
    "success" => true,
    "message" => "Code verified successfully",
    "token" => $token
]);

$stmt->close();
$conn->close();
?>