<?php
// Enable error reporting for debugging - remove in production
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set PHP timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

header("Content-Type: application/json");
require_once 'connection.php';

// Set MySQL session timezone to Malaysia
$conn->query("SET time_zone = '+08:00'");

// Get JSON POST data
$data = json_decode(file_get_contents("php://input"), true);
$email = trim($data['email'] ?? '');
$code = trim($data['code'] ?? '');

// Basic input validation
if (empty($email) || empty($code)) {
    echo json_encode([
        "success" => false,
        "message" => "Email and reset code are required."
    ]);
    exit();
}

// Debug log for incoming data
error_log("Verify Reset Code Request: email=$email, code=$code");

// Prepare SQL to find matching reset code and check expiration
$stmt = $conn->prepare("SELECT id, reset_code, reset_code_expires FROM petsitter WHERE Email = ? AND reset_code = ? AND reset_code_expires > NOW()");
if (!$stmt) {
    echo json_encode([
        "success" => false,
        "message" => "Database prepare failed: " . $conn->error
    ]);
    exit();
}

$stmt->bind_param("ss", $email, $code);

if (!$stmt->execute()) {
    echo json_encode([
        "success" => false,
        "message" => "Database execute failed: " . $stmt->error
    ]);
    exit();
}

$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();
    error_log("Reset code valid, expires at: " . $row['reset_code_expires']);

    // Generate a secure token for password reset (valid for 1 hour)
    $token = bin2hex(random_bytes(32));
    $expires = date("Y-m-d H:i:s", strtotime("+1 hour"));

    // Update token and expiration in DB
    $updateStmt = $conn->prepare("UPDATE petsitter SET reset_token = ?, reset_token_expires = ? WHERE Email = ?");
    if (!$updateStmt) {
        echo json_encode([
            "success" => false,
            "message" => "Update prepare failed: " . $conn->error
        ]);
        exit();
    }

    $updateStmt->bind_param("sss", $token, $expires, $email);
    if (!$updateStmt->execute()) {
        echo json_encode([
            "success" => false,
            "message" => "Update execute failed: " . $updateStmt->error
        ]);
        exit();
    }

    $updateStmt->close();

    echo json_encode([
        "success" => true,
        "token" => $token,
        "message" => "Code verified. You can now reset your password."
    ]);
} else {
    error_log("Invalid or expired reset code for email: $email with code: $code");

    echo json_encode([
        "success" => false,
        "message" => "Invalid or expired reset code.",
        "debug" => [
            "email" => $email,
            "code" => $code,
            "server_time" => date("Y-m-d H:i:s")
        ]
    ]);
}

$stmt->close();
$conn->close();
?>
