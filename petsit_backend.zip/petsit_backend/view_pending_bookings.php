<?php
header('Content-Type: application/json');
include 'config.php'; // Make sure BASE_URL is defined here

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get completed bookings
$sql = "SELECT booking_id, service_name, FromDate, ToDate, TotalPrice, booking_date, petOwner_ID, petSitter_ID 
        FROM booking 
        WHERE approval = 'pending'";

$result = $conn->query($sql);

$bookings = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $bookings[] = $row;
    }
}

// Close connection
$conn->close();

// Return JSON response
echo json_encode($bookings);
?>
