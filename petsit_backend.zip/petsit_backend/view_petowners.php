<?php
header('Content-Type: application/json');
include 'config.php';
// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "petsit";

// Base URL (replace with your local IP if testing on device)
$ipAddress = BASE_URL;// ✅ Change to your actual IP address
$imagePath = "/";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select pet owners with profile image
$sql = "SELECT id, FirstName, LastName, Email, Phone_Number, Location, Gender, ProfileImage FROM petowner";
$result = $conn->query($sql);

$petOwners = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // If ProfileImage is null, use default
        if (is_null($row['ProfileImage']) || $row['ProfileImage'] == "") {
            $row['ProfileImage'] = $ipAddress . $imagePath . "default_profile.jpg";
        } else {
            $row['ProfileImage'] = $ipAddress . $imagePath . $row['ProfileImage'];
        }
        $petOwners[] = $row;
    }
}

// Close connection
$conn->close();

// Return JSON response
echo json_encode($petOwners);
?>
