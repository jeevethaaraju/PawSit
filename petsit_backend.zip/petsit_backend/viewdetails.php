<?php
header('Content-Type: application/json');

// Include config file
require_once 'config.php';

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$db = "petsit"; // 🔁 Change this to your actual DB name

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Database connection failed"]));
}

// Check if petsitter_id is provided
if (!isset($_GET['petsitter_id'])) {
    echo json_encode(["success" => false, "message" => "Missing petsitter_id"]);
    exit;
}

$petsitter_id = intval($_GET['petsitter_id']);

// Query to get picture1, picture2, picture3 from services table
$sql = "SELECT id,picture1, picture2, picture3 FROM services WHERE petsitter_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $petsitter_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $pictures = $result->fetch_assoc();

    // Prefix with base URL from config
    foreach ($pictures as $key => $value) {
        if (!empty($value)) {
            $pictures[$key] = BASE_URL . $value;
        }
    }

    echo json_encode(["success" => true, "data" => $pictures]);
} else {
    echo json_encode(["success" => false, "message" => "No service found for this petsitter_id"]);
}

$stmt->close();
$conn->close();
?>